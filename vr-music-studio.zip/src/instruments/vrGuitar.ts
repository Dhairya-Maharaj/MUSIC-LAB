import * as THREE from 'three';
import { SoundEngine } from '../audio/soundEngine';

export interface StringMeshInfo {
  index: number;
  note: string;
  name: string;
  freq: number;
  mesh: THREE.Line | THREE.Mesh;
  vibrating: boolean;
  vibrateTimer: number;
  vibrateAmplitude: number;
  basePoints: THREE.Vector3[];
  lastControllerPos: THREE.Vector3 | null;
}

export class VRGuitar {
  public group: THREE.Group;
  public standGroup: THREE.Group;
  public tutorialGroup: THREE.Group;

  // State
  public isHeld: boolean = false;
  public holdingControllerIndex: number | null = null; // 0 or 1
  public isLeftHanded: boolean = false;

  // Sound & Strings
  private soundEngine: SoundEngine;
  private strings: StringMeshInfo[] = [];
  private readonly STRING_NAMES = ['Low E', 'A', 'D', 'G', 'B', 'High E'];
  private readonly STRING_NOTES = ['E2', 'A2', 'D3', 'G3', 'B3', 'E4'];
  private readonly STRING_FREQS = [82.41, 110.00, 146.83, 196.00, 246.94, 329.63];

  // Rest position on stand
  public standPosition = new THREE.Vector3(-1.4, 0.0, -1.2);
  public standGuitarPosition = new THREE.Vector3(-1.4, 0.45, -1.2);
  public standGuitarRotation = new THREE.Euler(0.2, 0.5, 0.0);

  // Grab collision spheres
  private bodyGrabPoint = new THREE.Vector3(0, 0, 0);
  private neckGrabPoint = new THREE.Vector3(0, 0.45, 0);

  // Strum tracking for hands
  private lastHandLocalPos: THREE.Vector3 = new THREE.Vector3();
  private hasHandPrevPos: boolean = false;

  // Visual materials
  private woodBodyMat!: THREE.MeshStandardMaterial;
  private fretboardMat!: THREE.MeshStandardMaterial;
  private stringMat!: THREE.LineBasicMaterial;
  private stringVibrateMat!: THREE.LineBasicMaterial;
  public strumHitMesh!: THREE.Mesh;

  constructor(soundEngine: SoundEngine) {
    this.soundEngine = soundEngine;
    this.group = new THREE.Group();
    this.standGroup = new THREE.Group();
    this.tutorialGroup = new THREE.Group();

    this.initMaterials();
    this.buildStand();
    this.buildGuitarModel();
    this.buildTutorialSign();

    // Place guitar initially resting on stand
    this.resetToStand();
  }

  private initMaterials() {
    this.woodBodyMat = new THREE.MeshStandardMaterial({
      color: 0x9e5b29, // Warm spruce / mahogany
      roughness: 0.35,
      metalness: 0.05,
    });

    this.fretboardMat = new THREE.MeshStandardMaterial({
      color: 0x24160d, // Dark rosewood
      roughness: 0.5,
    });

    this.stringMat = new THREE.LineBasicMaterial({
      color: 0xd8d8d8,
      linewidth: 1,
    });

    this.stringVibrateMat = new THREE.LineBasicMaterial({
      color: 0x60a5fa, // Glowing vibrating blue-white
      linewidth: 2,
    });
  }

  private buildStand() {
    this.standGroup.position.copy(this.standPosition);

    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x1f2428,
      roughness: 0.4,
      metalness: 0.8,
    });

    const rubberMat = new THREE.MeshStandardMaterial({
      color: 0x111111,
      roughness: 0.8,
    });

    // Base tripod
    const baseHub = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.06, 12), metalMat);
    baseHub.position.y = 0.06;
    this.standGroup.add(baseHub);

    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.42, 8), metalMat);
      leg.position.set(Math.cos(angle) * 0.2, 0.04, Math.sin(angle) * 0.2);
      leg.rotation.z = Math.PI / 2;
      leg.rotation.y = -angle;
      this.standGroup.add(leg);

      // Rubber feet
      const foot = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), rubberMat);
      foot.position.set(Math.cos(angle) * 0.38, 0.02, Math.sin(angle) * 0.38);
      this.standGroup.add(foot);
    }

    // Vertical stem
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.85, 12), metalMat);
    stem.position.set(0, 0.45, 0);
    this.standGroup.add(stem);

    // Lower cradle (holds guitar base)
    const cradleCross = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.26, 8), rubberMat);
    cradleCross.rotation.z = Math.PI / 2;
    cradleCross.position.set(0, 0.22, 0.08);
    this.standGroup.add(cradleCross);

    // Upper neck cradle
    const neckCradle = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 8, 16, Math.PI), rubberMat);
    neckCradle.rotation.x = Math.PI / 2;
    neckCradle.position.set(0, 0.82, 0.04);
    this.standGroup.add(neckCradle);
  }

  private buildGuitarModel() {
    // Acoustic guitar body
    const bodyGroup = new THREE.Group();

    // Lower bout (wide round portion)
    const lowerBout = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.19, 0.09, 24),
      this.woodBodyMat
    );
    lowerBout.rotation.x = Math.PI / 2;
    lowerBout.position.set(0, -0.12, 0);
    bodyGroup.add(lowerBout);

    // Upper bout
    const upperBout = new THREE.Mesh(
      new THREE.CylinderGeometry(0.13, 0.14, 0.085, 24),
      this.woodBodyMat
    );
    upperBout.rotation.x = Math.PI / 2;
    upperBout.position.set(0, 0.08, 0);
    bodyGroup.add(upperBout);

    // Waist connector
    const waist = new THREE.Mesh(
      new THREE.BoxGeometry(0.24, 0.14, 0.088),
      this.woodBodyMat
    );
    waist.position.set(0, -0.02, 0);
    bodyGroup.add(waist);

    // Sound hole (black inset circle)
    const soundHoleMat = new THREE.MeshBasicMaterial({ color: 0x0a0a0a });
    const soundHole = new THREE.Mesh(new THREE.CircleGeometry(0.048, 24), soundHoleMat);
    soundHole.position.set(0, 0.02, 0.045);
    bodyGroup.add(soundHole);

    // Rosette decorative ring
    const rosetteMat = new THREE.MeshBasicMaterial({ color: 0xe2cfb5 });
    const rosette = new THREE.Mesh(new THREE.RingGeometry(0.048, 0.056, 24), rosetteMat);
    rosette.position.set(0, 0.02, 0.0451);
    bodyGroup.add(rosette);

    // Bridge
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.6 });
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.025, 0.012), bridgeMat);
    bridge.position.set(0, -0.18, 0.048);
    bodyGroup.add(bridge);

    // Saddle
    const saddleMat = new THREE.MeshStandardMaterial({ color: 0xf5eedc, roughness: 0.3 });
    const saddle = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.005, 0.006), saddleMat);
    saddle.position.set(0, -0.175, 0.054);
    bodyGroup.add(saddle);

    // Neck
    const neck = new THREE.Mesh(
      new THREE.BoxGeometry(0.046, 0.42, 0.026),
      this.fretboardMat
    );
    neck.position.set(0, 0.35, 0.022);
    bodyGroup.add(neck);

    // Frets (nickel wire markers along neck)
    const fretMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.9, roughness: 0.2 });
    for (let f = 1; f <= 15; f++) {
      const fretY = 0.16 + (f * 0.025);
      const fret = new THREE.Mesh(new THREE.CylinderGeometry(0.001, 0.001, 0.044, 6), fretMat);
      fret.rotation.z = Math.PI / 2;
      fret.position.set(0, fretY, 0.036);
      bodyGroup.add(fret);

      // Fret dots at 3, 5, 7, 9, 12
      if ([3, 5, 7, 9, 12].includes(f)) {
        const dot = new THREE.Mesh(new THREE.CircleGeometry(0.003, 10), saddleMat);
        dot.position.set(0, fretY - 0.012, 0.036);
        bodyGroup.add(dot);
      }
    }

    // Headstock
    const headstock = new THREE.Mesh(
      new THREE.BoxGeometry(0.065, 0.14, 0.022),
      this.woodBodyMat
    );
    headstock.position.set(0, 0.62, 0.012);
    headstock.rotation.x = -0.15; // Realistic headstock tilt
    bodyGroup.add(headstock);

    // Tuning pegs (3 on left, 3 on right)
    const pegMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.2 });
    for (let p = 0; p < 3; p++) {
      const pegY = 0.58 + p * 0.04;
      // Left peg
      const pegL = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.03, 8), pegMat);
      pegL.rotation.z = Math.PI / 2;
      pegL.position.set(-0.045, pegY, 0.012);
      bodyGroup.add(pegL);

      // Right peg
      const pegR = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.03, 8), pegMat);
      pegR.rotation.z = Math.PI / 2;
      pegR.position.set(0.045, pegY, 0.012);
      bodyGroup.add(pegR);
    }

    // Build the 6 Interactive Strings
    this.strings = [];
    const stringSpread = 0.034; // Total width across 6 strings at bridge
    const numPoints = 16;

    for (let i = 0; i < 6; i++) {
      const t = (i / 5) - 0.5; // -0.5 to 0.5
      const bridgeX = t * stringSpread;
      const nutX = t * (stringSpread * 0.8);

      const pStart = new THREE.Vector3(bridgeX, -0.175, 0.054);
      const pEnd = new THREE.Vector3(nutX, 0.56, 0.037);

      const basePoints: THREE.Vector3[] = [];
      for (let pt = 0; pt < numPoints; pt++) {
        const factor = pt / (numPoints - 1);
        const point = new THREE.Vector3().lerpVectors(pStart, pEnd, factor);
        basePoints.push(point);
      }

      const geom = new THREE.BufferGeometry().setFromPoints(basePoints);
      const line = new THREE.Line(geom, this.stringMat.clone());
      bodyGroup.add(line);

      this.strings.push({
        index: i,
        name: this.STRING_NAMES[i],
        note: this.STRING_NOTES[i],
        freq: this.STRING_FREQS[i],
        mesh: line,
        vibrating: false,
        vibrateTimer: 0,
        vibrateAmplitude: 0,
        basePoints,
        lastControllerPos: null,
      });
    }

    // Interactive Strum Hit Plane (detects pointer clicks and VR lasers)
    const strumPlaneGeom = new THREE.PlaneGeometry(0.34, 0.76);
    const strumPlaneMat = new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide });
    this.strumHitMesh = new THREE.Mesh(strumPlaneGeom, strumPlaneMat);
    this.strumHitMesh.position.set(0, 0.18, 0.05);
    this.strumHitMesh.name = 'guitar_strum_plane';
    bodyGroup.add(this.strumHitMesh);

    this.group.add(bodyGroup);
  }

  private buildTutorialSign() {
    this.tutorialGroup.position.set(-1.4, 1.25, -1.2);
    this.tutorialGroup.rotation.y = 0.5;

    // Sign background board
    const boardMat = new THREE.MeshStandardMaterial({
      color: 0x18181b, // Dark slate
      roughness: 0.6,
      metalness: 0.2,
    });
    const board = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.55, 0.02), boardMat);
    this.tutorialGroup.add(board);

    // Frame border
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46 });
    const frameTop = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.02, 0.025), frameMat);
    frameTop.position.y = 0.28;
    this.tutorialGroup.add(frameTop);

    // Canvas texture for clean VR text
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 800;
    const ctx = canvas.getContext('2d')!;

    // Background gradient
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, 1024, 800);

    // Header badge
    ctx.fillStyle = '#2563eb';
    ctx.roundRect(40, 40, 260, 48, 8);
    ctx.fill();

    ctx.font = 'bold 28px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('VR GUITAR GUIDE', 55, 74);

    // Title
    ctx.font = 'bold 36px sans-serif';
    ctx.fillStyle = '#f4f4f5';
    ctx.fillText('How to Hold & Strum', 40, 140);

    // Steps
    const steps = [
      { num: '1', title: 'Pick Up Guitar', desc: 'Reach out and hold controller GRIP button near neck or body.' },
      { num: '2', title: 'Natural Hold', desc: 'Hold guitar naturally. Toggle Left/Right handed mode in settings.' },
      { num: '3', title: 'Strum Strings', desc: 'Move your other hand across strings to pluck or strum smoothly.' },
      { num: '4', title: 'Dynamic Notes', desc: '6 strings: Low E -> A -> D -> G -> B -> High E. Velocity responsive!' },
      { num: '5', title: 'Put Down', desc: 'Release GRIP button near the stand to park the guitar.' },
    ];

    let y = 200;
    steps.forEach(step => {
      // Step pill
      ctx.fillStyle = '#1e293b';
      ctx.roundRect(40, y - 28, 44, 44, 10);
      ctx.fill();

      ctx.font = 'bold 26px sans-serif';
      ctx.fillStyle = '#38bdf8';
      ctx.fillText(step.num, 54, y + 4);

      ctx.font = 'bold 28px sans-serif';
      ctx.fillStyle = '#e2e8f0';
      ctx.fillText(step.title, 105, y);

      ctx.font = '22px sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(step.desc, 105, y + 32);

      y += 90;
    });

    // Rosette note labels at bottom
    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('Strings: E2 | A2 | D3 | G3 | B3 | E4', 40, 750);

    const texture = new THREE.CanvasTexture(canvas);
    const canvasMat = new THREE.MeshBasicMaterial({ map: texture });
    const textMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.66, 0.51), canvasMat);
    textMesh.position.z = 0.012;
    this.tutorialGroup.add(textMesh);
  }

  public resetToStand() {
    this.isHeld = false;
    this.holdingControllerIndex = null;
    this.group.position.copy(this.standGuitarPosition);
    this.group.rotation.copy(this.standGuitarRotation);
    this.soundEngine.setGuitarPosition(this.standGuitarPosition.x, this.standGuitarPosition.y, this.standGuitarPosition.z);
  }

  public setHandedness(leftHanded: boolean) {
    this.isLeftHanded = leftHanded;
    if (this.group) {
      this.group.scale.x = leftHanded ? -1 : 1;
    }
  }

  /**
   * Check if controller can grab guitar
   */
  public canGrab(controllerWorldPos: THREE.Vector3): boolean {
    const guitarWorldPos = new THREE.Vector3();
    this.group.getWorldPosition(guitarWorldPos);
    return guitarWorldPos.distanceTo(controllerWorldPos) < 0.45;
  }

  /**
   * Attach guitar to controller
   */
  public grab(controllerIndex: number) {
    this.isHeld = true;
    this.holdingControllerIndex = controllerIndex;
  }

  /**
   * Release guitar; returns true if snapped back to stand
   */
  public release(): boolean {
    this.isHeld = false;
    this.holdingControllerIndex = null;

    // Check distance to stand
    const guitarPos = this.group.position;
    const distToStand = guitarPos.distanceTo(this.standGuitarPosition);

    if (distToStand < 0.85) {
      this.resetToStand();
      return true;
    } else {
      // Sits smoothly on the floor or stays at drop location
      this.group.position.y = Math.max(0.1, this.group.position.y);
      this.soundEngine.setGuitarPosition(this.group.position.x, this.group.position.y, this.group.position.z);
      return false;
    }
  }

  /**
   * Update guitar position when held by VR controller
   */
  public updateHeldPosition(controllerPos: THREE.Vector3, controllerQuat: THREE.Quaternion) {
    if (!this.isHeld) return;

    // Offset guitar naturally like holding the guitar against the player's body
    this.group.position.copy(controllerPos);
    this.group.quaternion.copy(controllerQuat);

    // Apply natural guitar posture rotation
    // Tilt upward ~35 deg, slight body tilt
    const tilt = new THREE.Quaternion().setFromEuler(
      new THREE.Euler(
        this.isLeftHanded ? 0.3 : 0.4,
        this.isLeftHanded ? 0.6 : -0.6,
        this.isLeftHanded ? -0.4 : 0.4
      )
    );
    this.group.quaternion.multiply(tilt);

    // Slightly offset along controller forward
    const offset = new THREE.Vector3(this.isLeftHanded ? 0.12 : -0.12, -0.15, -0.1);
    offset.applyQuaternion(this.group.quaternion);
    this.group.position.add(offset);

    // Update spatial audio position
    this.soundEngine.setGuitarPosition(this.group.position.x, this.group.position.y, this.group.position.z);
  }

  /**
   * Test hand / controller strumming across strings
   * Returns plucked string index or -1
   */
  public checkStrum(strummingWorldPos: THREE.Vector3, deltaSeconds: number): { stringIndex: number; velocity: number } | null {
    // Transform hand position into guitar local space
    const handLocal = strummingWorldPos.clone();
    this.group.worldToLocal(handLocal);

    if (!this.hasHandPrevPos) {
      this.lastHandLocalPos.copy(handLocal);
      this.hasHandPrevPos = true;
      return null;
    }

    const prevLocal = this.lastHandLocalPos.clone();
    this.lastHandLocalPos.copy(handLocal);

    // Strum zone check:
    // Y: between -0.22 (bridge) and +0.22 (soundhole/neck joint)
    // Z: height above guitar face: 0.02 to 0.12
    // X: across strings: -0.05 to +0.05
    if (handLocal.y < -0.25 || handLocal.y > 0.25) return null;
    if (handLocal.z < 0.01 || handLocal.z > 0.15) return null;

    // Calculate hand speed
    const moveDist = prevLocal.distanceTo(handLocal);
    const speed = deltaSeconds > 0 ? moveDist / deltaSeconds : 1.0;
    const velocity = Math.min(1.0, Math.max(0.25, speed * 0.4));

    // Check each string X crossing
    for (let i = 0; i < this.strings.length; i++) {
      const stringData = this.strings[i];
      // String X position around sound hole / bridge
      const stringX = ((i / 5) - 0.5) * 0.034;

      // Crossing check: previously on one side, now on the other, or within threshold
      const crossed = (prevLocal.x <= stringX && handLocal.x >= stringX) ||
                      (prevLocal.x >= stringX && handLocal.x <= stringX);

      const closeTouch = Math.abs(handLocal.x - stringX) < 0.008 &&
                         Math.abs(handLocal.z - 0.05) < 0.035;

      if (crossed || closeTouch) {
        if (!stringData.vibrating || stringData.vibrateTimer < 0.05) {
          this.triggerStringVibration(i, velocity);
          return { stringIndex: i, velocity };
        }
      }
    }

    return null;
  }

  /**
   * Trigger string vibration animation
   */
  public triggerStringVibration(index: number, velocity: number = 0.8) {
    if (index < 0 || index >= this.strings.length) return;
    const str = this.strings[index];
    str.vibrating = true;
    str.vibrateTimer = 0.35; // 350ms vibration
    str.vibrateAmplitude = 0.008 * velocity;
    (str.mesh as THREE.Line).material = this.stringVibrateMat;
  }

  /**
   * Handle raycast strumming (from mouse clicks/drags in 3D mode or VR lasers)
   */
  public handleRaycast(ray: THREE.Ray, velocity: number = 0.85): { stringIndex: number; velocity: number } | null {
    if (!this.strumHitMesh) return null;
    const raycaster = new THREE.Raycaster();
    raycaster.ray.copy(ray);
    const intersects = raycaster.intersectObject(this.strumHitMesh, false);
    if (intersects.length > 0) {
      const hitPointLocal = this.group.worldToLocal(intersects[0].point.clone());
      // Map local X (-0.02 to +0.02) to string index (0 to 5)
      const normalizedX = (hitPointLocal.x / 0.038) + 0.5;
      const stringIndex = Math.max(0, Math.min(5, Math.round(normalizedX * 5)));
      
      this.triggerStringVibration(stringIndex, velocity);
      this.soundEngine.playGuitarString(stringIndex, velocity);
      return { stringIndex, velocity };
    }
    return null;
  }

  /**
   * Animation update for string vibration physics
   */
  public update(delta: number) {
    this.strings.forEach(str => {
      if (str.vibrating) {
        str.vibrateTimer -= delta;
        if (str.vibrateTimer <= 0) {
          str.vibrating = false;
          (str.mesh as THREE.Line).material = this.stringMat;
          // Reset string points
          const geom = str.mesh.geometry as THREE.BufferGeometry;
          const posAttr = geom.attributes.position as THREE.BufferAttribute;
          for (let p = 0; p < str.basePoints.length; p++) {
            posAttr.setXYZ(p, str.basePoints[p].x, str.basePoints[p].y, str.basePoints[p].z);
          }
          posAttr.needsUpdate = true;
        } else {
          // Harmonic wave displacement along string
          const geom = str.mesh.geometry as THREE.BufferGeometry;
          const posAttr = geom.attributes.position as THREE.BufferAttribute;
          const decay = str.vibrateTimer / 0.35;
          const freq = str.freq * 0.1;
          const time = performance.now() * 0.03;

          for (let p = 0; p < str.basePoints.length; p++) {
            const base = str.basePoints[p];
            const standingWave = Math.sin((p / (str.basePoints.length - 1)) * Math.PI);
            const displacement = Math.sin(time + p * 0.4) * str.vibrateAmplitude * decay * standingWave;

            posAttr.setXYZ(p, base.x + displacement, base.y, base.z + Math.abs(displacement) * 0.5);
          }
          posAttr.needsUpdate = true;
        }
      }
    });
  }
}
