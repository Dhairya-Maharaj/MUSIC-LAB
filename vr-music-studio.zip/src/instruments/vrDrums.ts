import * as THREE from 'three';
import { SoundEngine } from '../audio/soundEngine';

export interface DrumHitZone {
  id: string;
  name: string;
  type: 'drum' | 'cymbal';
  mesh: THREE.Mesh | THREE.Group;
  worldCenter: THREE.Vector3;
  radius: number;
  height: number;
  normal: THREE.Vector3;
  // Visual reaction
  originalPosition: THREE.Vector3;
  originalRotation: THREE.Euler;
  wobbleAngle: number;
  wobbleVelocity: number;
  hitFlashTimer: number;
}

export interface DrumStick {
  id: 'left' | 'right';
  group: THREE.Group;
  isHeld: boolean;
  holdingControllerIndex: number | null;
  prevTipPos: THREE.Vector3;
  currTipPos: THREE.Vector3;
  initialPos: THREE.Vector3;
  initialRot: THREE.Euler;
}

export class VRDrums {
  public group: THREE.Group;
  public stickTableGroup: THREE.Group;
  private soundEngine: SoundEngine;

  // Drum zones
  public hitZones: DrumHitZone[] = [];
  public drumSticks: DrumStick[] = [];

  // Materials
  private chromeMat!: THREE.MeshStandardMaterial;
  private shellBlackMat!: THREE.MeshStandardMaterial;
  private drumHeadMat!: THREE.MeshStandardMaterial;
  private cymbalMat!: THREE.MeshStandardMaterial;
  private woodStickMat!: THREE.MeshStandardMaterial;

  // Base positioning in room
  public kitPosition = new THREE.Vector3(1.3, 0.0, -1.6);
  public stickTablePosition = new THREE.Vector3(0.5, 0.0, -1.2);

  constructor(soundEngine: SoundEngine) {
    this.soundEngine = soundEngine;
    this.group = new THREE.Group();
    this.stickTableGroup = new THREE.Group();

    this.initMaterials();
    this.buildKit();
    this.buildStickTable();
    this.buildDrumSticks();

    this.group.position.copy(this.kitPosition);
    this.stickTableGroup.position.copy(this.stickTablePosition);
  }

  private initMaterials() {
    this.chromeMat = new THREE.MeshStandardMaterial({
      color: 0xcccccc,
      metalness: 0.95,
      roughness: 0.15,
    });

    this.shellBlackMat = new THREE.MeshStandardMaterial({
      color: 0x141416, // Piano black gloss lacquer
      metalness: 0.2,
      roughness: 0.25,
    });

    this.drumHeadMat = new THREE.MeshStandardMaterial({
      color: 0xf4f4f5, // Coated white drumhead
      roughness: 0.6,
      metalness: 0.05,
    });

    this.cymbalMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Hammered B20 bronze
      metalness: 0.85,
      roughness: 0.35,
    });

    this.woodStickMat = new THREE.MeshStandardMaterial({
      color: 0xddb17f, // Hickory wood
      roughness: 0.5,
    });
  }

  private buildKit() {
    // 1. Kick Drum (Bass Drum)
    const kickGroup = new THREE.Group();
    kickGroup.position.set(0, 0.42, 0);

    // Shell cylinder (laid horizontally)
    const kickShell = new THREE.Mesh(
      new THREE.CylinderGeometry(0.38, 0.38, 0.45, 32),
      this.shellBlackMat
    );
    kickShell.rotation.x = Math.PI / 2;
    kickGroup.add(kickShell);

    // Rims / Hoops
    const hoopMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.4 });
    const frontHoop = new THREE.Mesh(new THREE.TorusGeometry(0.385, 0.02, 12, 32), hoopMat);
    frontHoop.position.set(0, 0, -0.23);
    kickGroup.add(frontHoop);

    const backHoop = new THREE.Mesh(new THREE.TorusGeometry(0.385, 0.02, 12, 32), hoopMat);
    backHoop.position.set(0, 0, 0.23);
    kickGroup.add(backHoop);

    // Front Resonant Head (facing room)
    const frontHead = new THREE.Mesh(new THREE.CircleGeometry(0.375, 32), this.shellBlackMat);
    frontHead.position.set(0, 0, -0.228);
    frontHead.rotation.y = Math.PI;
    kickGroup.add(frontHead);

    // Batter Head (facing player) - Interactive surface
    const kickBatterHead = new THREE.Mesh(new THREE.CircleGeometry(0.375, 32), this.drumHeadMat);
    kickBatterHead.position.set(0, 0, 0.228);
    kickGroup.add(kickBatterHead);

    // Kick Spurs / Legs
    for (let s of [-1, 1]) {
      const spur = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.45, 8), this.chromeMat);
      spur.position.set(s * 0.42, -0.22, -0.1);
      spur.rotation.z = s * 0.5;
      kickGroup.add(spur);
    }

    // Pedal Mechanism
    const pedalBase = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.02, 0.24), this.chromeMat);
    pedalBase.position.set(0, -0.4, 0.26);
    kickGroup.add(pedalBase);

    const beater = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.22, 8), this.chromeMat);
    beater.position.set(0, -0.25, 0.25);
    kickGroup.add(beater);

    const beaterHead = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.04, 12), hoopMat);
    beaterHead.rotation.x = Math.PI / 2;
    beaterHead.position.set(0, -0.14, 0.24);
    kickGroup.add(beaterHead);

    this.group.add(kickGroup);

    this.registerHitZone('kick', 'Kick Drum', 'drum', kickBatterHead, 0.35, new THREE.Vector3(0, 0, 1));

    // 2. Snare Drum
    const snareGroup = new THREE.Group();
    snareGroup.position.set(-0.38, 0.72, 0.26);
    snareGroup.rotation.x = 0.1; // slight player tilt

    // Chrome metal shell
    const snareShell = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.20, 0.16, 28), this.chromeMat);
    snareGroup.add(snareShell);

    // Top drumhead
    const snareHead = new THREE.Mesh(new THREE.CircleGeometry(0.195, 28), this.drumHeadMat);
    snareHead.rotation.x = -Math.PI / 2;
    snareHead.position.y = 0.082;
    snareGroup.add(snareHead);

    // Rim
    const snareRim = new THREE.Mesh(new THREE.TorusGeometry(0.202, 0.012, 8, 28), this.chromeMat);
    snareRim.rotation.x = Math.PI / 2;
    snareRim.position.y = 0.085;
    snareGroup.add(snareRim);

    // Snare Stand Basket
    const snareStand = this.createCylinderStand(0.68, this.chromeMat);
    snareStand.position.set(0, -0.38, 0);
    snareGroup.add(snareStand);

    this.group.add(snareGroup);
    this.registerHitZone('snare', 'Snare Drum', 'drum', snareHead, 0.19, new THREE.Vector3(0, 1, 0));

    // 3. High Tom (Mounted on kick drum left)
    const tomHighGroup = new THREE.Group();
    tomHighGroup.position.set(-0.2, 0.88, -0.05);
    tomHighGroup.rotation.set(0.35, -0.2, 0);

    const tomHighShell = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.20, 24), this.shellBlackMat);
    tomHighGroup.add(tomHighShell);

    const tomHighHead = new THREE.Mesh(new THREE.CircleGeometry(0.155, 24), this.drumHeadMat);
    tomHighHead.rotation.x = -Math.PI / 2;
    tomHighHead.position.y = 0.102;
    tomHighGroup.add(tomHighHead);

    const tomHighRim = new THREE.Mesh(new THREE.TorusGeometry(0.162, 0.01, 8, 24), this.chromeMat);
    tomHighRim.rotation.x = Math.PI / 2;
    tomHighRim.position.y = 0.105;
    tomHighGroup.add(tomHighRim);

    this.group.add(tomHighGroup);
    this.registerHitZone('tom_high', 'High Tom', 'drum', tomHighHead, 0.15, new THREE.Vector3(0, 1, 0));

    // 4. Mid Tom (Mounted on kick drum right)
    const tomMidGroup = new THREE.Group();
    tomMidGroup.position.set(0.18, 0.88, -0.05);
    tomMidGroup.rotation.set(0.35, 0.2, 0);

    const tomMidShell = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.22, 24), this.shellBlackMat);
    tomMidGroup.add(tomMidShell);

    const tomMidHead = new THREE.Mesh(new THREE.CircleGeometry(0.165, 24), this.drumHeadMat);
    tomMidHead.rotation.x = -Math.PI / 2;
    tomMidHead.position.y = 0.112;
    tomMidGroup.add(tomMidHead);

    const tomMidRim = new THREE.Mesh(new THREE.TorusGeometry(0.172, 0.01, 8, 24), this.chromeMat);
    tomMidRim.rotation.x = Math.PI / 2;
    tomMidRim.position.y = 0.115;
    tomMidGroup.add(tomMidRim);

    this.group.add(tomMidGroup);
    this.registerHitZone('tom_mid', 'Mid Tom', 'drum', tomMidHead, 0.16, new THREE.Vector3(0, 1, 0));

    // 5. Floor Tom (Stand on right)
    const floorTomGroup = new THREE.Group();
    floorTomGroup.position.set(0.48, 0.68, 0.28);
    floorTomGroup.rotation.x = 0.08;

    const floorTomShell = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.38, 28), this.shellBlackMat);
    floorTomGroup.add(floorTomShell);

    const floorTomHead = new THREE.Mesh(new THREE.CircleGeometry(0.235, 28), this.drumHeadMat);
    floorTomHead.rotation.x = -Math.PI / 2;
    floorTomHead.position.y = 0.192;
    floorTomGroup.add(floorTomHead);

    const floorTomRim = new THREE.Mesh(new THREE.TorusGeometry(0.242, 0.012, 8, 28), this.chromeMat);
    floorTomRim.rotation.x = Math.PI / 2;
    floorTomRim.position.y = 0.195;
    floorTomGroup.add(floorTomRim);

    // 3 chrome legs
    for (let l = 0; l < 3; l++) {
      const angle = (l * Math.PI * 2) / 3;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.68, 8), this.chromeMat);
      leg.position.set(Math.cos(angle) * 0.26, -0.32, Math.sin(angle) * 0.26);
      floorTomGroup.add(leg);
    }

    this.group.add(floorTomGroup);
    this.registerHitZone('tom_floor', 'Floor Tom', 'drum', floorTomHead, 0.23, new THREE.Vector3(0, 1, 0));

    // 6. Hi-Hat Stand & Cymbals (Left)
    const hiHatGroup = new THREE.Group();
    hiHatGroup.position.set(-0.68, 0.96, 0.12);

    const hiHatStand = this.createCylinderStand(0.96, this.chromeMat);
    hiHatStand.position.y = -0.48;
    hiHatGroup.add(hiHatStand);

    // Top cymbal
    const hiHatTop = this.createCymbalMesh(0.20, 0.02);
    hiHatGroup.add(hiHatTop);

    // Bottom cymbal
    const hiHatBottom = this.createCymbalMesh(0.20, -0.02);
    hiHatBottom.position.y = -0.025;
    hiHatGroup.add(hiHatBottom);

    this.group.add(hiHatGroup);
    this.registerHitZone('hihat_closed', 'Hi-Hat', 'cymbal', hiHatTop, 0.20, new THREE.Vector3(0, 1, 0));

    // 7. Crash Cymbal (Left / Front)
    const crashGroup = new THREE.Group();
    crashGroup.position.set(-0.55, 1.25, -0.32);
    crashGroup.rotation.set(0.3, -0.2, 0);

    const crashStand = this.createCylinderStand(1.25, this.chromeMat);
    crashStand.position.set(0, -0.62, 0);
    crashStand.rotation.set(-0.3, 0.2, 0); // counteract angle for vertical pole
    crashGroup.add(crashStand);

    const crashCymbal = this.createCymbalMesh(0.25, 0.035);
    crashGroup.add(crashCymbal);

    this.group.add(crashGroup);
    this.registerHitZone('crash', 'Crash Cymbal', 'cymbal', crashCymbal, 0.25, new THREE.Vector3(0, 1, 0));

    // 8. Ride Cymbal (Right / Back)
    const rideGroup = new THREE.Group();
    rideGroup.position.set(0.62, 1.15, -0.15);
    rideGroup.rotation.set(0.25, 0.35, 0);

    const rideStand = this.createCylinderStand(1.15, this.chromeMat);
    rideStand.position.set(0, -0.57, 0);
    rideStand.rotation.set(-0.25, -0.35, 0);
    rideGroup.add(rideStand);

    const rideCymbal = this.createCymbalMesh(0.28, 0.04);
    rideGroup.add(rideCymbal);

    this.group.add(rideGroup);
    this.registerHitZone('ride', 'Ride Cymbal', 'cymbal', rideCymbal, 0.28, new THREE.Vector3(0, 1, 0));
  }

  private createCymbalMesh(radius: number, bellHeight: number): THREE.Mesh {
    const geom = new THREE.ConeGeometry(radius, bellHeight, 32, 1, true);
    const cymbal = new THREE.Mesh(geom, this.cymbalMat);
    cymbal.rotation.x = Math.PI; // Bell points up
    return cymbal;
  }

  private createCylinderStand(height: number, material: THREE.Material): THREE.Group {
    const stand = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, height, 10), material);
    stand.add(pole);

    // Tripod base at bottom
    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.42, 8), material);
      leg.position.set(Math.cos(angle) * 0.18, -height / 2 + 0.12, Math.sin(angle) * 0.18);
      leg.rotation.z = Math.PI / 2.3;
      leg.rotation.y = -angle;
      stand.add(leg);
    }
    return stand;
  }

  private registerHitZone(
    id: string,
    name: string,
    type: 'drum' | 'cymbal',
    mesh: THREE.Mesh | THREE.Group,
    radius: number,
    normal: THREE.Vector3
  ) {
    this.hitZones.push({
      id,
      name,
      type,
      mesh,
      worldCenter: new THREE.Vector3(),
      radius,
      height: 0.1,
      normal,
      originalPosition: mesh.position.clone(),
      originalRotation: mesh.rotation.clone(),
      wobbleAngle: 0,
      wobbleVelocity: 0,
      hitFlashTimer: 0,
    });
  }

  private buildStickTable() {
    const tableMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.7,
      metalness: 0.3,
    });

    const top = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.03, 0.28), tableMat);
    top.position.y = 0.75;
    this.stickTableGroup.add(top);

    // Felt top mat
    const feltMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.9 });
    const felt = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.005, 0.24), feltMat);
    felt.position.set(0, 0.768, 0);
    this.stickTableGroup.add(felt);

    // Chrome legs
    for (let x of [-0.18, 0.18]) {
      for (let z of [-0.11, 0.11]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.75, 8), this.chromeMat);
        leg.position.set(x, 0.375, z);
        this.stickTableGroup.add(leg);
      }
    }

    // Sign "DRUMSTICKS"
    const signMat = new THREE.MeshBasicMaterial({ color: 0x60a5fa });
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.05), signMat);
    sign.position.set(0, 0.75, 0.145);
    this.stickTableGroup.add(sign);
  }

  private buildDrumSticks() {
    this.drumSticks = [];

    const stickConfigs: Array<{ id: 'left' | 'right'; xOffset: number }> = [
      { id: 'left', xOffset: -0.08 },
      { id: 'right', xOffset: 0.08 },
    ];

    stickConfigs.forEach(cfg => {
      const stickGroup = new THREE.Group();

      // Drumstick handle + body
      const stickMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.007, 0.009, 0.38, 12),
        this.woodStickMat
      );
      // Center cylinder so tip is at (0, 0.22, 0) and handle is at (0, -0.16, 0)
      stickMesh.position.y = 0.03;
      stickGroup.add(stickMesh);

      // Grip tape wrap on handle
      const gripMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.8 });
      const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.0095, 0.0095, 0.14, 12), gripMat);
      grip.position.y = -0.09;
      stickGroup.add(grip);

      // Wooden tip
      const tipMesh = new THREE.Mesh(new THREE.SphereGeometry(0.009, 10, 10), this.woodStickMat);
      tipMesh.position.y = 0.22;
      stickGroup.add(tipMesh);

      // Resting on stick table
      const initialPos = new THREE.Vector3(
        this.stickTablePosition.x + cfg.xOffset,
        this.stickTablePosition.y + 0.78,
        this.stickTablePosition.z
      );
      const initialRot = new THREE.Euler(Math.PI / 2, 0, 0);

      stickGroup.position.copy(initialPos);
      stickGroup.rotation.copy(initialRot);

      this.group.add(stickGroup);

      this.drumSticks.push({
        id: cfg.id,
        group: stickGroup,
        isHeld: false,
        holdingControllerIndex: null,
        prevTipPos: new THREE.Vector3(),
        currTipPos: new THREE.Vector3(),
        initialPos,
        initialRot,
      });
    });
  }

  public resetStickToTable(stickId: 'left' | 'right') {
    const stick = this.drumSticks.find(s => s.id === stickId);
    if (!stick) return;

    stick.isHeld = false;
    stick.holdingControllerIndex = null;
    stick.group.position.copy(stick.initialPos);
    stick.group.rotation.copy(stick.initialRot);
  }

  public canGrabStick(controllerWorldPos: THREE.Vector3): DrumStick | null {
    for (const stick of this.drumSticks) {
      if (stick.isHeld) continue;
      const stickPos = new THREE.Vector3();
      stick.group.getWorldPosition(stickPos);
      if (stickPos.distanceTo(controllerWorldPos) < 0.28) {
        return stick;
      }
    }
    return null;
  }

  public grabStick(stickId: 'left' | 'right', controllerIndex: number) {
    const stick = this.drumSticks.find(s => s.id === stickId);
    if (!stick) return;

    stick.isHeld = true;
    stick.holdingControllerIndex = controllerIndex;
  }

  public releaseStick(stickId: 'left' | 'right') {
    const stick = this.drumSticks.find(s => s.id === stickId);
    if (!stick) return;

    stick.isHeld = false;
    stick.holdingControllerIndex = null;

    // Check if released near stick table or reset back
    const stickPos = stick.group.position;
    if (stickPos.distanceTo(this.stickTablePosition) < 0.6) {
      this.resetStickToTable(stickId);
    } else {
      // Keep on floor / stand
      stick.group.position.y = Math.max(0.05, stick.group.position.y);
    }
  }

  /**
   * Update stick position while held in VR hand
   */
  public updateHeldStick(stick: DrumStick, controllerPos: THREE.Vector3, controllerQuat: THREE.Quaternion) {
    if (!stick.isHeld) return;

    stick.group.position.copy(controllerPos);
    stick.group.quaternion.copy(controllerQuat);

    // Tilt stick forward from hand naturally like a drummer holds it
    const stickHoldTilt = new THREE.Quaternion().setFromEuler(new THREE.Euler(-0.4, 0, 0));
    stick.group.quaternion.multiply(stickHoldTilt);

    // Tip position in world space: tip is at local (0, 0.22, 0)
    const tipLocal = new THREE.Vector3(0, 0.22, 0);
    const tipWorld = tipLocal.applyQuaternion(stick.group.quaternion).add(stick.group.position);

    stick.prevTipPos.copy(stick.currTipPos);
    stick.currTipPos.copy(tipWorld);
  }

  /**
   * Check for collisions between drumsticks and drum hit zones
   * Returns triggered hits with hit zone info, stick, and impact velocity
   */
  public checkHits(delta: number): Array<{ hitZone: DrumHitZone; stick: DrumStick; velocity: number }> {
    const hits: Array<{ hitZone: DrumHitZone; stick: DrumStick; velocity: number }> = [];

    // Update world centers of hit zones
    for (const zone of this.hitZones) {
      zone.mesh.getWorldPosition(zone.worldCenter);
    }

    for (const stick of this.drumSticks) {
      if (!stick.isHeld) continue;

      const p1 = stick.prevTipPos;
      const p2 = stick.currTipPos;

      if (p1.lengthSq() === 0) continue; // Skip first frame

      const travelDist = p1.distanceTo(p2);
      if (travelDist < 0.001) continue;

      const speed = delta > 0 ? travelDist / delta : 1.0;
      const impactVelocity = Math.min(1.0, Math.max(0.25, speed * 0.35));

      for (const zone of this.hitZones) {
        // Distance to drum zone surface center
        const distToCenter = p2.distanceTo(zone.worldCenter);
        if (distToCenter > zone.radius * 1.3) continue;

        // Check if movement crossed the plane or entered the target cylinder
        const heightDiff = p2.y - zone.worldCenter.y;
        const prevHeightDiff = p1.y - zone.worldCenter.y;

        // Downward stroke or penetration into zone
        const crossedDownward = (prevHeightDiff >= 0 && heightDiff <= 0.04) ||
                                (Math.abs(heightDiff) < 0.04 && distToCenter <= zone.radius);

        if (crossedDownward && zone.hitFlashTimer <= 0) {
          this.triggerHitReaction(zone, impactVelocity);
          hits.push({ hitZone: zone, stick, velocity: impactVelocity });
        }
      }
    }

    return hits;
  }

  /**
   * Visual hit animation: drum skin impulse or cymbal wobble oscillation
   */
  public triggerZoneVisual(id: string, velocity: number = 0.8) {
    const zone = this.hitZones.find(z => z.id === id);
    if (zone) {
      this.triggerHitReaction(zone, velocity);
    }
  }

  public triggerHitReaction(zone: DrumHitZone, velocity: number = 0.8) {
    zone.hitFlashTimer = 0.12; // Prevent double-triggering for 120ms

    if (zone.type === 'cymbal') {
      zone.wobbleVelocity = (0.45 * velocity);
    } else {
      // Drum skin downward bounce
      zone.mesh.position.y = zone.originalPosition.y - 0.018 * velocity;
    }
  }

  /**
   * Handle raycast strike on drums / cymbals (from mouse click or VR laser)
   */
  public handleRaycast(ray: THREE.Ray, velocity: number = 0.85): { hitZone: DrumHitZone; velocity: number } | null {
    const raycaster = new THREE.Raycaster();
    raycaster.ray.copy(ray);

    // Collect meshes
    const candidates: THREE.Object3D[] = [];
    for (const zone of this.hitZones) {
      candidates.push(zone.mesh);
    }

    const intersects = raycaster.intersectObjects(candidates, true);
    if (intersects.length > 0) {
      const hitObj = intersects[0].object;
      const matchedZone = this.hitZones.find(z => {
        if (z.mesh === hitObj) return true;
        let isChild = false;
        z.mesh.traverse(child => {
          if (child === hitObj) isChild = true;
        });
        return isChild;
      });

      if (matchedZone) {
        this.triggerHitReaction(matchedZone, velocity);
        this.soundEngine.playDrum(matchedZone.id, velocity);
        return { hitZone: matchedZone, velocity };
      }
    }
    return null;
  }

  /**
   * Animation update for cymbals wobble physics and drum bounce return
   */
  public update(delta: number) {
    for (const zone of this.hitZones) {
      if (zone.hitFlashTimer > 0) {
        zone.hitFlashTimer -= delta;
      }

      if (zone.type === 'cymbal') {
        if (Math.abs(zone.wobbleVelocity) > 0.001 || Math.abs(zone.wobbleAngle) > 0.001) {
          // Damped harmonic oscillator for realistic cymbal oscillation
          const springK = 110;
          const damping = 9;
          const force = -springK * zone.wobbleAngle;
          zone.wobbleVelocity += (force - damping * zone.wobbleVelocity) * delta;
          zone.wobbleAngle += zone.wobbleVelocity * delta;

          zone.mesh.rotation.x = zone.originalRotation.x + zone.wobbleAngle;
          zone.mesh.rotation.z = zone.originalRotation.z + zone.wobbleAngle * 0.4;
        } else {
          zone.mesh.rotation.copy(zone.originalRotation);
        }
      } else {
        // Return drum head to neutral position smoothly
        if (zone.mesh.position.y !== zone.originalPosition.y) {
          zone.mesh.position.y = THREE.MathUtils.lerp(zone.mesh.position.y, zone.originalPosition.y, delta * 18);
        }
      }
    }
  }
}
