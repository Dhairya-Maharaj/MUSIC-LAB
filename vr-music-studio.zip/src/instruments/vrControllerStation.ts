import * as THREE from 'three';
import { ControllerPadConfig } from '../types';
import { SoundEngine } from '../audio/soundEngine';

export interface PadMeshItem {
  id: number;
  config: ControllerPadConfig;
  mesh: THREE.Mesh;
  labelMesh?: THREE.Mesh;
  material: THREE.MeshStandardMaterial;
  baseY: number;
  currentY: number;
  targetY: number;
  lightIntensity: number;
  worldPos: THREE.Vector3;
}

export interface BeatButtonMesh {
  id: 'lofi' | 'house' | 'trap' | 'stop';
  mesh: THREE.Mesh;
  material: THREE.MeshStandardMaterial;
  worldPos: THREE.Vector3;
  label: string;
}

export class VRControllerStation {
  public group: THREE.Group;
  private soundEngine: SoundEngine;

  // Visual pad meshes
  public pads: PadMeshItem[] = [];
  public beatButtons: BeatButtonMesh[] = [];

  // Knobs & Fader
  private filterKnobMesh!: THREE.Mesh;
  private filterAngle: number = 0; // -135 to +135 deg

  // VU Meters
  private vuLedsLeft: THREE.Mesh[] = [];
  private vuLedsRight: THREE.Mesh[] = [];
  private vuLevel: number = 0;

  // Collision bounding box for quick rejection
  private stationBounds: THREE.Box3 = new THREE.Box3();
  private consoleMesh!: THREE.Mesh;

  // Debounce for physical touches
  private padLastHitTimes: Float32Array = new Float32Array(16);

  constructor(soundEngine: SoundEngine) {
    this.soundEngine = soundEngine;
    this.group = new THREE.Group();

    // Position station conveniently in the music area
    // Just to the left of center, right within reach from player start
    this.group.position.set(-0.55, 0, -1.25);
    this.group.rotation.y = THREE.MathUtils.degToRad(18); // Angled comfortably toward player center

    this.buildStand();
    this.buildChassis();
    this.buildPads();
    this.buildControls();
    this.buildBeatLooperSection();
    this.buildVuMeters();
    this.buildInfoPlate();

    this.updateWorldMatrices();
  }

  private updateWorldMatrices() {
    this.group.updateMatrixWorld(true);
    this.stationBounds.setFromObject(this.group);

    // Cache world coordinates of pads for zero-allocation collision checks
    this.pads.forEach(p => {
      p.mesh.getWorldPosition(p.worldPos);
    });
    this.beatButtons.forEach(b => {
      b.mesh.getWorldPosition(b.worldPos);
    });
  }

  private buildStand() {
    // Heavy tripod studio base
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      metalness: 0.85,
      roughness: 0.25,
    });
    const standGroup = new THREE.Group();

    const basePlate = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 0.035, 24), baseMat);
    basePlate.position.y = 0.018;
    standGroup.add(basePlate);

    // Telescoping center pole
    const poleMat = new THREE.MeshStandardMaterial({
      color: 0x3f3f46,
      metalness: 0.9,
      roughness: 0.2,
    });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.86, 16), poleMat);
    pole.position.y = 0.44;
    standGroup.add(pole);

    // Chrome collar clutch
    const clutchMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.95, roughness: 0.1 });
    const clutch = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.06, 16), clutchMat);
    clutch.position.y = 0.65;
    standGroup.add(clutch);

    // Walnut trim accent on stand head
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.4 });
    const woodTrim = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.03, 0.28), woodMat);
    woodTrim.position.set(0, 0.87, 0);
    woodTrim.rotation.x = THREE.MathUtils.degToRad(-30);
    standGroup.add(woodTrim);

    this.group.add(standGroup);
  }

  private buildChassis() {
    // Angled Controller Deck
    const deckGroup = new THREE.Group();
    deckGroup.position.set(0, 0.89, 0);
    deckGroup.rotation.x = THREE.MathUtils.degToRad(-30); // Ergonomic 30 degree playing tilt

    // Anodized dark aluminum chassis
    const chassisMat = new THREE.MeshStandardMaterial({
      color: 0x111317,
      metalness: 0.75,
      roughness: 0.35,
    });
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.04, 0.36), chassisMat);
    chassis.castShadow = true;
    chassis.receiveShadow = true;
    this.consoleMesh = chassis;
    deckGroup.add(chassis);

    // Top faceplate (Brushed gunmetal)
    const faceplateMat = new THREE.MeshStandardMaterial({
      color: 0x1f242d,
      metalness: 0.6,
      roughness: 0.4,
    });
    const faceplate = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.005, 0.34), faceplateMat);
    faceplate.position.y = 0.022;
    deckGroup.add(faceplate);

    // Side cheeks: oiled teak wood end caps
    const cheekMat = new THREE.MeshStandardMaterial({
      color: 0x92400e,
      roughness: 0.35,
      metalness: 0.05,
    });
    [-0.245, 0.245].forEach(x => {
      const cheek = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.046, 0.364), cheekMat);
      cheek.position.set(x, 0, 0);
      deckGroup.add(cheek);
    });

    this.group.add(deckGroup);
  }

  private buildPads() {
    // 16 RGB velocity performance pads arranged in 4x4 grid
    const configs: ControllerPadConfig[] = [
      // Row 0: Chords
      { id: 0, name: 'Cmaj7', category: 'chord', color: 0x818cf8, label: 'Cmaj7' },
      { id: 1, name: 'Am7', category: 'chord', color: 0x6366f1, label: 'Am7' },
      { id: 2, name: 'Fmaj7', category: 'chord', color: 0xa855f7, label: 'Fmaj7' },
      { id: 3, name: 'G9', category: 'chord', color: 0xc084fc, label: 'G9' },
      // Row 1: 808 Sub Bass
      { id: 4, name: '808 C1', category: 'bass', color: 0x0ea5e9, label: '808 C' },
      { id: 5, name: '808 Eb1', category: 'bass', color: 0x0284c7, label: '808 Eb' },
      { id: 6, name: '808 F1', category: 'bass', color: 0x0369a1, label: '808 F' },
      { id: 7, name: '808 G1', category: 'bass', color: 0x38bdf8, label: '808 G' },
      // Row 2: Electronic Beats
      { id: 8, name: 'Kick', category: 'beat', color: 0xf59e0b, label: 'Kick' },
      { id: 9, name: 'Clap', category: 'beat', color: 0xd97706, label: 'Clap' },
      { id: 10, name: 'Hat', category: 'beat', color: 0x10b981, label: 'Hat' },
      { id: 11, name: 'Open', category: 'beat', color: 0x059669, label: 'Open' },
      // Row 3: Stabs & FX
      { id: 12, name: 'Laser', category: 'fx', color: 0xf43f5e, label: 'Laser' },
      { id: 13, name: 'Vocal', category: 'fx', color: 0xe11d48, label: 'Vocal' },
      { id: 14, name: 'Scratch', category: 'fx', color: 0xec4899, label: 'Scratch' },
      { id: 15, name: 'Brass', category: 'fx', color: 0xfb7185, label: 'Brass' },
    ];

    const padGeom = new THREE.BoxGeometry(0.045, 0.012, 0.045);
    const startX = -0.13;
    const startZ = -0.06;
    const spacingX = 0.055;
    const spacingZ = 0.055;

    // We attach pads to the angled deck coordinate frame
    const deck = this.group.children[1] as THREE.Group;

    configs.forEach((cfg, idx) => {
      const col = idx % 4;
      const row = Math.floor(idx / 4);

      const posX = startX + col * spacingX;
      const posZ = startZ + row * spacingZ;
      const posY = 0.026;

      const padMat = new THREE.MeshStandardMaterial({
        color: cfg.color,
        emissive: cfg.color,
        emissiveIntensity: 0.35,
        roughness: 0.25,
        metalness: 0.1,
        transparent: true,
        opacity: 0.95,
      });

      const padMesh = new THREE.Mesh(padGeom, padMat);
      padMesh.position.set(posX, posY, posZ);
      padMesh.castShadow = true;
      padMesh.name = `controller_pad_${cfg.id}`;
      deck.add(padMesh);

      // Pad bevel border ring
      const bezelMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.8 });
      const bezel = new THREE.Mesh(new THREE.BoxGeometry(0.049, 0.008, 0.049), bezelMat);
      bezel.position.set(posX, 0.023, posZ);
      deck.add(bezel);

      this.pads.push({
        id: cfg.id,
        config: cfg,
        mesh: padMesh,
        material: padMat,
        baseY: posY,
        currentY: posY,
        targetY: posY,
        lightIntensity: 0.35,
        worldPos: new THREE.Vector3(),
      });
    });
  }

  private buildControls() {
    const deck = this.group.children[1] as THREE.Group;

    // Filter Cutoff Rotary Knob (Top Right)
    const knobGroup = new THREE.Group();
    knobGroup.position.set(0.16, 0.03, -0.08);

    const knobBodyMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      metalness: 0.9,
      roughness: 0.2,
    });
    const knobMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.022, 0.022, 20), knobBodyMat);
    knobMesh.name = 'controller_knob_filter';
    this.filterKnobMesh = knobMesh;
    knobGroup.add(knobMesh);

    // Indicator notch on knob
    const notchMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const notch = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.024, 0.008), notchMat);
    notch.position.set(0, 0.002, 0.015);
    knobMesh.add(notch);

    // Dial ring around knob with glowing LED tick marks
    const dialRingMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const dialRing = new THREE.Mesh(new THREE.RingGeometry(0.024, 0.028, 20), dialRingMat);
    dialRing.rotation.x = -Math.PI / 2;
    dialRing.position.y = -0.006;
    knobGroup.add(dialRing);

    deck.add(knobGroup);
  }

  private buildBeatLooperSection() {
    const deck = this.group.children[1] as THREE.Group;

    const beatConfigs: Array<{ id: 'lofi' | 'house' | 'trap' | 'stop'; color: number; label: string; z: number }> = [
      { id: 'lofi', color: 0x38bdf8, label: 'Lo-Fi 86', z: -0.02 },
      { id: 'house', color: 0xa855f7, label: 'House 124', z: 0.035 },
      { id: 'trap', color: 0xf59e0b, label: 'Trap 140', z: 0.09 },
      { id: 'stop', color: 0xef4444, label: 'Stop Beat', z: 0.145 },
    ];

    const btnGeom = new THREE.BoxGeometry(0.065, 0.014, 0.032);
    const posX = 0.16;

    beatConfigs.forEach(b => {
      const mat = new THREE.MeshStandardMaterial({
        color: b.color,
        emissive: b.color,
        emissiveIntensity: b.id === 'stop' ? 0.3 : 0.2,
        roughness: 0.3,
        metalness: 0.2,
      });

      const btn = new THREE.Mesh(btnGeom, mat);
      btn.position.set(posX, 0.026, b.z);
      btn.name = `controller_beat_${b.id}`;
      deck.add(btn);

      this.beatButtons.push({
        id: b.id,
        mesh: btn,
        material: mat,
        worldPos: new THREE.Vector3(),
        label: b.label,
      });
    });
  }

  private buildVuMeters() {
    const deck = this.group.children[1] as THREE.Group;
    const meterSegments = 8;
    const segWidth = 0.008;
    const segHeight = 0.006;
    const segDepth = 0.006;
    const startZ = 0.12;

    for (let i = 0; i < meterSegments; i++) {
      const isRed = i >= 6;
      const isYellow = i >= 4 && i < 6;
      const col = isRed ? 0xef4444 : isYellow ? 0xeab308 : 0x22c55e;

      const segMatL = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.25 });
      const segMatR = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.25 });

      const segL = new THREE.Mesh(new THREE.BoxGeometry(segWidth, segHeight, segDepth), segMatL);
      const segR = new THREE.Mesh(new THREE.BoxGeometry(segWidth, segHeight, segDepth), segMatR);

      const zPos = startZ - i * 0.009;
      segL.position.set(0.10, 0.024, zPos);
      segR.position.set(0.115, 0.024, zPos);

      deck.add(segL);
      deck.add(segR);

      this.vuLedsLeft.push(segL);
      this.vuLedsRight.push(segR);
    }
  }

  private buildInfoPlate() {
    const deck = this.group.children[1] as THREE.Group;

    // Header badge plate
    const badgeMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      metalness: 0.9,
      roughness: 0.3,
    });
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.004, 0.026), badgeMat);
    badge.position.set(-0.04, 0.024, -0.13);
    deck.add(badge);

    // Glowing cyan studio brand strip
    const brandStripMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const brandStrip = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.002, 0.004), brandStripMat);
    brandStrip.position.set(-0.04, 0.026, -0.13);
    deck.add(brandStrip);
  }

  /**
   * Check physical touch from VR controller tip or drumstick
   */
  public checkPhysicalHit(controllerPos: THREE.Vector3, velocity: number = 0.85): number | null {
    // Quick bounding distance check
    if (this.group.position.distanceTo(controllerPos) > 0.85) {
      return null;
    }

    const now = performance.now();
    const hitRadiusSq = 0.042 * 0.042; // ~4.2cm trigger radius around pad center

    for (let i = 0; i < this.pads.length; i++) {
      const pad = this.pads[i];
      // Debounce pad hits to prevent double triggering (minimum 85ms between triggers)
      if (now - this.padLastHitTimes[i] < 85) continue;

      const distSq = pad.worldPos.distanceToSquared(controllerPos);
      if (distSq < hitRadiusSq) {
        this.padLastHitTimes[i] = now;
        this.triggerPad(pad.id, velocity);
        return pad.id;
      }
    }

    // Check Beat looper buttons
    for (let i = 0; i < this.beatButtons.length; i++) {
      const b = this.beatButtons[i];
      const distSq = b.worldPos.distanceToSquared(controllerPos);
      if (distSq < 0.038 * 0.038) {
        this.clickBeatButton(b.id);
        return -1;
      }
    }

    return null;
  }

  /**
   * Trigger pad hit (play audio, flash LED, compress pad spring)
   */
  public triggerPad(padId: number, velocity: number = 0.85) {
    const pad = this.pads[padId];
    if (!pad) return;

    // Audio synthesis
    this.soundEngine.playControllerPad(padId, velocity, true);

    // Visual feedback
    pad.targetY = pad.baseY - 0.007; // Mechanical depression
    pad.lightIntensity = 1.6; // RGB flash
    pad.material.emissiveIntensity = 1.6;

    // Bump VU meter
    this.vuLevel = Math.min(1.0, this.vuLevel + velocity * 0.7);
  }

  /**
   * Click Beat button
   */
  public clickBeatButton(btnId: 'lofi' | 'house' | 'trap' | 'stop') {
    if (btnId === 'stop') {
      this.soundEngine.stopBackingBeat();
    } else {
      this.soundEngine.toggleBackingBeat(btnId);
    }
    this.updateBeatButtonVisuals();
  }

  private updateBeatButtonVisuals() {
    const activePattern = this.soundEngine.getBackingBeatPattern();
    this.beatButtons.forEach(b => {
      if (b.id === activePattern) {
        b.material.emissiveIntensity = 1.4;
      } else {
        b.material.emissiveIntensity = b.id === 'stop' ? 0.3 : 0.2;
      }
    });
  }

  /**
   * Handle raycast laser hit from VR controller
   */
  public handleRaycast(ray: THREE.Ray): boolean {
    const deck = this.group.children[1] as THREE.Group;
    if (!deck) return false;

    // Check hit with console chassis first
    const raycaster = new THREE.Raycaster();
    raycaster.ray.copy(ray);
    const intersects = raycaster.intersectObjects([this.consoleMesh, ...this.pads.map(p => p.mesh), ...this.beatButtons.map(b => b.mesh)], false);

    if (intersects.length > 0) {
      const hitObj = intersects[0].object;
      if (hitObj.name.startsWith('controller_pad_')) {
        const id = parseInt(hitObj.name.replace('controller_pad_', ''), 10);
        this.triggerPad(id, 0.9);
        return true;
      } else if (hitObj.name.startsWith('controller_beat_')) {
        const id = hitObj.name.replace('controller_beat_', '') as 'lofi' | 'house' | 'trap' | 'stop';
        this.clickBeatButton(id);
        return true;
      } else if (hitObj.name === 'controller_knob_filter') {
        // Toggle filter frequency sweep on knob click
        this.filterAngle = (this.filterAngle + 45) % 360;
        this.filterKnobMesh.rotation.y = THREE.MathUtils.degToRad(this.filterAngle);
        const norm = (this.filterAngle % 360) / 360;
        this.soundEngine.setFilterCutoff(400 + norm * 14000);
        return true;
      }
    }

    return false;
  }

  /**
   * Frame update for spring physics and VU meters
   */
  public update(delta: number) {
    this.updateWorldMatrices();

    // 1. Pad spring animations
    this.pads.forEach(pad => {
      // Spring back to base position
      pad.currentY += (pad.targetY - pad.currentY) * Math.min(1.0, delta * 25);
      pad.mesh.position.y = pad.currentY;
      pad.targetY += (pad.baseY - pad.targetY) * Math.min(1.0, delta * 18);

      // Fade emissive flash back to idle
      if (pad.lightIntensity > 0.35) {
        pad.lightIntensity = Math.max(0.35, pad.lightIntensity - delta * 4.5);
        pad.material.emissiveIntensity = pad.lightIntensity;
      }
    });

    // 2. Beat button pulse if active
    const activePattern = this.soundEngine.getBackingBeatPattern();
    if (activePattern !== 'none') {
      const pulse = 0.9 + Math.sin(performance.now() * 0.008) * 0.4;
      const activeBtn = this.beatButtons.find(b => b.id === activePattern);
      if (activeBtn) {
        activeBtn.material.emissiveIntensity = pulse;
      }
      this.vuLevel = Math.max(this.vuLevel, 0.5 + Math.sin(performance.now() * 0.015) * 0.3);
    }

    // 3. VU Meters decay
    this.vuLevel = Math.max(0, this.vuLevel - delta * 2.2);
    const activeSegments = Math.round(this.vuLevel * 8);

    for (let i = 0; i < 8; i++) {
      const isLit = i < activeSegments;
      const ledMatL = this.vuLedsLeft[i].material as THREE.MeshBasicMaterial;
      const ledMatR = this.vuLedsRight[i].material as THREE.MeshBasicMaterial;
      ledMatL.opacity = isLit ? 1.0 : 0.15;
      ledMatR.opacity = isLit ? 1.0 : 0.15;
    }
  }
}
