import * as THREE from 'three';
import { AudioSettings, PerformanceEvent, RecorderState } from '../types';

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private guitarGain: GainNode | null = null;
  private drumGain: GainNode | null = null;
  private controllerGain: GainNode | null = null;
  private controllerFilter: BiquadFilterNode | null = null;
  private guitarPanner: PannerNode | null = null;
  private drumPanner: PannerNode | null = null;
  private controllerPanner: PannerNode | null = null;

  // Backing beat looper
  private backingBeatIntervalId: number | null = null;
  private backingBeatPattern: string = 'none';
  private backingBeatStep: number = 0;

  // Recording state
  private isRecording = false;
  private isPlaying = false;
  private recordStartTime = 0;
  private recordedEvents: PerformanceEvent[] = [];
  private playbackTimeoutIds: number[] = [];
  private onReplayEventCallback: ((event: PerformanceEvent) => void) | null = null;
  private onRecorderStateChange: ((state: RecorderState) => void) | null = null;

  // Settings
  private settings: AudioSettings = {
    masterVolume: 0.85,
    guitarVolume: 0.9,
    drumVolume: 0.95,
    controllerVolume: 0.9,
  };

  // Pre-calculated Karplus-Strong string buffers for instant zero-latency playback
  private guitarBuffers: Map<number, AudioBuffer> = new Map();

  constructor() {
    // Lazy initialize on first interaction/VR start
  }

  public init() {
    if (this.ctx) return;

    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioContextClass();

    // Master bus
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(this.settings.masterVolume, this.ctx.currentTime);
    this.masterGain.connect(this.ctx.destination);

    // Guitar bus + Spatial Panner
    this.guitarGain = this.ctx.createGain();
    this.guitarGain.gain.setValueAtTime(this.settings.guitarVolume, this.ctx.currentTime);

    this.guitarPanner = this.ctx.createPanner();
    this.guitarPanner.panningModel = 'HRTF';
    this.guitarPanner.distanceModel = 'inverse';
    this.guitarPanner.refDistance = 1.2;
    this.guitarPanner.maxDistance = 25;
    this.guitarPanner.rolloffFactor = 1.0;
    this.setGuitarPosition(-1.2, 1.0, -1.5);

    this.guitarGain.connect(this.guitarPanner);
    this.guitarPanner.connect(this.masterGain);

    // Drum bus + Spatial Panner
    this.drumGain = this.ctx.createGain();
    this.drumGain.gain.setValueAtTime(this.settings.drumVolume, this.ctx.currentTime);

    this.drumPanner = this.ctx.createPanner();
    this.drumPanner.panningModel = 'HRTF';
    this.drumPanner.distanceModel = 'inverse';
    this.drumPanner.refDistance = 1.5;
    this.drumPanner.maxDistance = 25;
    this.drumPanner.rolloffFactor = 1.0;
    this.setDrumPosition(1.3, 0.8, -1.8);

    this.drumGain.connect(this.drumPanner);
    this.drumPanner.connect(this.masterGain);

    // Controller bus + Spatial Panner + Master Lowpass Filter
    this.controllerGain = this.ctx.createGain();
    this.controllerGain.gain.setValueAtTime(this.settings.controllerVolume, this.ctx.currentTime);

    this.controllerFilter = this.ctx.createBiquadFilter();
    this.controllerFilter.type = 'lowpass';
    this.controllerFilter.frequency.setValueAtTime(14000, this.ctx.currentTime);
    this.controllerFilter.Q.setValueAtTime(1.5, this.ctx.currentTime);

    this.controllerPanner = this.ctx.createPanner();
    this.controllerPanner.panningModel = 'HRTF';
    this.controllerPanner.distanceModel = 'inverse';
    this.controllerPanner.refDistance = 1.2;
    this.controllerPanner.maxDistance = 25;
    this.controllerPanner.rolloffFactor = 1.0;
    this.setControllerPosition(-0.55, 0.95, -1.2);

    this.controllerGain.connect(this.controllerFilter);
    this.controllerFilter.connect(this.controllerPanner);
    this.controllerPanner.connect(this.masterGain);

    // Pre-synthesize Karplus-Strong strings
    this.generateGuitarBuffers();
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public updateListener(
    posXOrVec: number | THREE.Vector3,
    posYOrQuat?: number | THREE.Quaternion,
    posZ?: number,
    forwardX?: number,
    forwardY?: number,
    forwardZ?: number,
    upX?: number,
    upY?: number,
    upZ?: number
  ) {
    if (!this.ctx) return;
    let px = 0, py = 0, pz = 0;
    let fx = 0, fy = 0, fz = -1;
    let ux = 0, uy = 1, uz = 0;

    if (typeof posXOrVec === 'object' && 'x' in posXOrVec) {
      px = posXOrVec.x;
      py = posXOrVec.y;
      pz = posXOrVec.z;
      if (posYOrQuat && typeof posYOrQuat === 'object' && 'w' in posYOrQuat) {
        const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(posYOrQuat);
        const up = new THREE.Vector3(0, 1, 0).applyQuaternion(posYOrQuat);
        fx = forward.x; fy = forward.y; fz = forward.z;
        ux = up.x; uy = up.y; uz = up.z;
      }
    } else {
      px = posXOrVec;
      py = (posYOrQuat as number) || 0;
      pz = posZ || 0;
      fx = forwardX ?? 0;
      fy = forwardY ?? 0;
      fz = forwardZ ?? -1;
      ux = upX ?? 0;
      uy = upY ?? 1;
      uz = upZ ?? 0;
    }

    const listener = this.ctx.listener;
    if (listener.positionX) {
      listener.positionX.setValueAtTime(px, this.ctx.currentTime);
      listener.positionY.setValueAtTime(py, this.ctx.currentTime);
      listener.positionZ.setValueAtTime(pz, this.ctx.currentTime);
      listener.forwardX.setValueAtTime(fx, this.ctx.currentTime);
      listener.forwardY.setValueAtTime(fy, this.ctx.currentTime);
      listener.forwardZ.setValueAtTime(fz, this.ctx.currentTime);
      listener.upX.setValueAtTime(ux, this.ctx.currentTime);
      listener.upY.setValueAtTime(uy, this.ctx.currentTime);
      listener.upZ.setValueAtTime(uz, this.ctx.currentTime);
    } else {
      // Fallback for older spec
      (listener as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(px, py, pz);
      (listener as unknown as { setOrientation: (fx: number, fy: number, fz: number, ux: number, uy: number, uz: number) => void }).setOrientation(fx, fy, fz, ux, uy, uz);
    }
  }

  public playDrumHit(drumId: string, velocity: number = 0.85, record: boolean = true) {
    this.playDrum(drumId, velocity, record);
  }

  public setGuitarPosition(x: number, y: number, z: number) {
    if (!this.guitarPanner || !this.ctx) return;
    if (this.guitarPanner.positionX) {
      this.guitarPanner.positionX.setValueAtTime(x, this.ctx.currentTime);
      this.guitarPanner.positionY.setValueAtTime(y, this.ctx.currentTime);
      this.guitarPanner.positionZ.setValueAtTime(z, this.ctx.currentTime);
    } else {
      (this.guitarPanner as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(x, y, z);
    }
  }

  public setDrumPosition(x: number, y: number, z: number) {
    if (!this.drumPanner || !this.ctx) return;
    if (this.drumPanner.positionX) {
      this.drumPanner.positionX.setValueAtTime(x, this.ctx.currentTime);
      this.drumPanner.positionY.setValueAtTime(y, this.ctx.currentTime);
      this.drumPanner.positionZ.setValueAtTime(z, this.ctx.currentTime);
    } else {
      (this.drumPanner as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(x, y, z);
    }
  }

  public setControllerPosition(x: number, y: number, z: number) {
    if (!this.controllerPanner || !this.ctx) return;
    if (this.controllerPanner.positionX) {
      this.controllerPanner.positionX.setValueAtTime(x, this.ctx.currentTime);
      this.controllerPanner.positionY.setValueAtTime(y, this.ctx.currentTime);
      this.controllerPanner.positionZ.setValueAtTime(z, this.ctx.currentTime);
    } else {
      (this.controllerPanner as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(x, y, z);
    }
  }

  // --- KARPLUS-STRONG STRING SYNTHESIS ---
  private generateGuitarBuffers() {
    if (!this.ctx) return;
    const sampleRate = this.ctx.sampleRate;
    // Standard 6 string frequencies: E2, A2, D3, G3, B3, E4
    const freqs = [82.41, 110.00, 146.83, 196.00, 246.94, 329.63];
    const duration = 2.8; // seconds

    freqs.forEach((freq, stringIdx) => {
      const numSamples = Math.floor(sampleRate * duration);
      const buffer = this.ctx!.createBuffer(1, numSamples, sampleRate);
      const channelData = buffer.getChannelData(0);

      const period = Math.round(sampleRate / freq);
      const ring = new Float32Array(period);

      // Initial excitation burst: warm noise burst simulating pick strike
      for (let i = 0; i < period; i++) {
        ring[i] = (Math.random() * 2 - 1) * 0.9;
      }

      // Karplus-Strong delay line with lowpass loss filter
      // Damping factor slightly increases with string index (thinner strings decay a bit faster)
      const damping = 0.992 - (stringIdx * 0.0015);
      let ringIndex = 0;
      let prevSample = 0;

      for (let i = 0; i < numSamples; i++) {
        const nextRingIndex = (ringIndex + 1) % period;
        // Averaging lowpass filter
        const currentVal = ring[ringIndex];
        const nextVal = ring[nextRingIndex];
        const newSample = 0.5 * (currentVal + nextVal) * damping;

        ring[ringIndex] = newSample;
        // Output with subtle low-end body resonance shaping
        channelData[i] = 0.8 * currentVal + 0.2 * prevSample;
        prevSample = channelData[i];

        ringIndex = nextRingIndex;
      }

      this.guitarBuffers.set(stringIdx, buffer);
    });
  }

  /**
   * Play guitar string note (0 = Low E, 5 = High E)
   */
  public playGuitarString(stringIdx: number, velocity: number = 0.8, record: boolean = true) {
    this.init();
    this.resume();
    if (!this.ctx || !this.guitarGain) return;

    const clampedVelocity = Math.max(0.15, Math.min(1.0, velocity));
    const buffer = this.guitarBuffers.get(stringIdx);
    if (!buffer) return;

    // Create source
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;

    // String velocity gain node
    const stringGain = this.ctx.createGain();
    const peakGain = 0.7 * clampedVelocity;
    stringGain.gain.setValueAtTime(peakGain, this.ctx.currentTime);
    stringGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 2.5);

    // Warm body resonance filter (simulates acoustic guitar wooden body)
    const bodyFilter = this.ctx.createBiquadFilter();
    bodyFilter.type = 'peaking';
    bodyFilter.frequency.setValueAtTime(210, this.ctx.currentTime);
    bodyFilter.Q.setValueAtTime(2.5, this.ctx.currentTime);
    bodyFilter.gain.setValueAtTime(4.0, this.ctx.currentTime);

    source.connect(bodyFilter);
    bodyFilter.connect(stringGain);
    stringGain.connect(this.guitarGain);

    source.start();

    // Record event if recording is active
    if (record && this.isRecording) {
      const noteNames = ['E2', 'A2', 'D3', 'G3', 'B3', 'E4'];
      this.recordEvent({
        time: performance.now() - this.recordStartTime,
        type: 'guitar',
        id: `string_${stringIdx}`,
        noteName: noteNames[stringIdx],
        velocity: clampedVelocity,
      });
    }
  }

  // --- DRUM SYNTHESIS ---
  public playDrum(drumId: string, velocity: number = 0.85, record: boolean = true) {
    this.init();
    this.resume();
    if (!this.ctx || !this.drumGain) return;

    const v = Math.max(0.2, Math.min(1.0, velocity));
    const now = this.ctx.currentTime;

    switch (drumId) {
      case 'kick':
        this.synthKick(now, v);
        break;
      case 'snare':
        this.synthSnare(now, v);
        break;
      case 'hihat_closed':
        this.synthHiHat(now, v, false);
        break;
      case 'hihat_open':
        this.synthHiHat(now, v, true);
        break;
      case 'crash':
        this.synthCrash(now, v);
        break;
      case 'ride':
        this.synthRide(now, v);
        break;
      case 'tom_high':
        this.synthTom(now, v, 175, 110, 0.28);
        break;
      case 'tom_mid':
        this.synthTom(now, v, 130, 85, 0.32);
        break;
      case 'tom_floor':
        this.synthTom(now, v, 95, 55, 0.40);
        break;
      default:
        this.synthSnare(now, v);
        break;
    }

    if (record && this.isRecording) {
      this.recordEvent({
        time: performance.now() - this.recordStartTime,
        type: 'drum',
        id: drumId,
        velocity: v,
      });
    }
  }

  private synthKick(now: number, velocity: number) {
    if (!this.ctx || !this.drumGain) return;

    // Pitch sweep sub oscillator
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(155, now);
    osc.frequency.exponentialRampToValueAtTime(36, now + 0.08);

    gain.gain.setValueAtTime(1.1 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

    // Beater impact click transient
    const clickOsc = this.ctx.createOscillator();
    const clickGain = this.ctx.createGain();
    clickOsc.type = 'triangle';
    clickOsc.frequency.setValueAtTime(450, now);
    clickOsc.frequency.exponentialRampToValueAtTime(60, now + 0.02);
    clickGain.gain.setValueAtTime(0.4 * velocity, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.025);

    osc.connect(gain);
    gain.connect(this.drumGain);

    clickOsc.connect(clickGain);
    clickGain.connect(this.drumGain);

    osc.start(now);
    osc.stop(now + 0.4);
    clickOsc.start(now);
    clickOsc.stop(now + 0.03);
  }

  private synthSnare(now: number, velocity: number) {
    if (!this.ctx || !this.drumGain) return;

    // Dual body tones
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const toneGain = this.ctx.createGain();

    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(185, now);
    osc1.frequency.exponentialRampToValueAtTime(120, now + 0.08);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(330, now);
    osc2.frequency.exponentialRampToValueAtTime(190, now + 0.06);

    toneGain.gain.setValueAtTime(0.5 * velocity, now);
    toneGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc1.connect(toneGain);
    osc2.connect(toneGain);
    toneGain.connect(this.drumGain);

    osc1.start(now);
    osc1.stop(now + 0.18);
    osc2.start(now);
    osc2.stop(now + 0.18);

    // Snare wire rattle (highpassed white noise)
    const noiseBuffer = this.createNoiseBuffer(0.24);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.setValueAtTime(1100, now);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.85 * velocity, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.drumGain);

    noiseSource.start(now);
  }

  private synthHiHat(now: number, velocity: number, isOpen: boolean) {
    if (!this.ctx || !this.drumGain) return;

    const decay = isOpen ? 0.45 : 0.065;

    // Cluster of metallic frequencies
    const freqs = [215, 318, 427, 545, 689, 830];
    const clusterGain = this.ctx.createGain();

    freqs.forEach(f => {
      const osc = this.ctx!.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(f, now);
      osc.connect(clusterGain);
      osc.start(now);
      osc.stop(now + decay);
    });

    const bandpass = this.ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(7400, now);
    bandpass.Q.setValueAtTime(1.8, now);

    const highpass = this.ctx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.setValueAtTime(6800, now);

    const envGain = this.ctx.createGain();
    envGain.gain.setValueAtTime(0.45 * velocity, now);
    envGain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

    clusterGain.connect(bandpass);
    bandpass.connect(highpass);
    highpass.connect(envGain);
    envGain.connect(this.drumGain);
  }

  private synthCrash(now: number, velocity: number) {
    if (!this.ctx || !this.drumGain) return;
    const duration = 2.0;

    const noiseBuffer = this.createNoiseBuffer(duration);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const filter1 = this.ctx.createBiquadFilter();
    filter1.type = 'highpass';
    filter1.frequency.setValueAtTime(3200, now);

    const filter2 = this.ctx.createBiquadFilter();
    filter2.type = 'peaking';
    filter2.frequency.setValueAtTime(6500, now);
    filter2.gain.setValueAtTime(6.0, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.9 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    noiseSource.connect(filter1);
    filter1.connect(filter2);
    filter2.connect(gain);
    gain.connect(this.drumGain);

    noiseSource.start(now);
  }

  private synthRide(now: number, velocity: number) {
    if (!this.ctx || !this.drumGain) return;
    const duration = 1.3;

    // Clear bell ping
    const bellOsc = this.ctx.createOscillator();
    bellOsc.type = 'sine';
    bellOsc.frequency.setValueAtTime(590, now);

    const bellGain = this.ctx.createGain();
    bellGain.gain.setValueAtTime(0.45 * velocity, now);
    bellGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    bellOsc.connect(bellGain);
    bellGain.connect(this.drumGain);
    bellOsc.start(now);
    bellOsc.stop(now + 0.4);

    // Shimmering metallic body
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.createNoiseBuffer(duration);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(4800, now);
    filter.Q.setValueAtTime(4.0, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.4 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.drumGain);

    noise.start(now);
  }

  private synthTom(now: number, velocity: number, startFreq: number, endFreq: number, decay: number) {
    if (!this.ctx || !this.drumGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(endFreq, now + decay * 0.45);

    gain.gain.setValueAtTime(0.85 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + decay);

    // Shell punch transient
    const click = this.ctx.createOscillator();
    const clickGain = this.ctx.createGain();
    click.type = 'triangle';
    click.frequency.setValueAtTime(startFreq * 2.2, now);
    clickGain.gain.setValueAtTime(0.3 * velocity, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

    osc.connect(gain);
    gain.connect(this.drumGain);

    click.connect(clickGain);
    clickGain.connect(this.drumGain);

    osc.start(now);
    osc.stop(now + decay + 0.05);
    click.start(now);
    click.stop(now + 0.04);
  }

  private createNoiseBuffer(duration: number): AudioBuffer {
    const sampleRate = this.ctx?.sampleRate || 44100;
    const numSamples = Math.floor(sampleRate * duration);
    const buffer = this.ctx!.createBuffer(1, numSamples, sampleRate);
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < numSamples; i++) {
      channel[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  // --- CONTROLLER SYNTHESIS & PADS ---
  public playControllerPad(padIdx: number, velocity: number = 0.85, record: boolean = true) {
    this.init();
    this.resume();
    if (!this.ctx || !this.controllerGain) return;

    const v = Math.max(0.2, Math.min(1.0, velocity));
    const now = this.ctx.currentTime;

    switch (padIdx) {
      // 0-3: Lush Synth Chords
      case 0:
        this.synthChord([261.63, 329.63, 392.00, 493.88], now, v); // Cmaj7
        break;
      case 1:
        this.synthChord([220.00, 261.63, 329.63, 392.00], now, v); // Am7
        break;
      case 2:
        this.synthChord([174.61, 220.00, 261.63, 329.63], now, v); // Fmaj7
        break;
      case 3:
        this.synthChord([196.00, 246.94, 293.66, 349.23, 440.00], now, v); // G9
        break;

      // 4-7: 808 Tuned Sub Bass
      case 4:
        this.synth808Sub(32.70, now, v); // C1
        break;
      case 5:
        this.synth808Sub(38.89, now, v); // Eb1
        break;
      case 6:
        this.synth808Sub(43.65, now, v); // F1
        break;
      case 7:
        this.synth808Sub(49.00, now, v); // G1
        break;

      // 8-11: Electronic Beat Stems
      case 8:
        this.synthElectroKick(now, v);
        break;
      case 9:
        this.synthElectroClap(now, v);
        break;
      case 10:
        this.synthElectroHat(now, v, false);
        break;
      case 11:
        this.synthElectroHat(now, v, true);
        break;

      // 12-15: Synth Stabs & Studio FX
      case 12:
        this.synthLaserDrop(now, v);
        break;
      case 13:
        this.synthVocalChop(now, v);
        break;
      case 14:
        this.synthVinylScratch(now, v);
        break;
      case 15:
        this.synthBrassStab(now, v);
        break;

      default:
        this.synthChord([261.63, 329.63, 392.00], now, v);
        break;
    }

    if (record && this.isRecording) {
      const padNames = [
        'Cmaj7', 'Am7', 'Fmaj7', 'G9',
        '808 C1', '808 Eb1', '808 F1', '808 G1',
        'Elec Kick', 'Clap Snare', '808 Hat', 'Open Hat',
        'Laser Drop', 'Vocal Chop', 'Vinyl FX', 'Brass Stab'
      ];
      this.recordEvent({
        time: performance.now() - this.recordStartTime,
        type: 'controller',
        id: `pad_${padIdx}`,
        noteName: padNames[padIdx] || `Pad ${padIdx}`,
        velocity: v,
      });
    }
  }

  private synthChord(freqs: number[], now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    freqs.forEach(freq => {
      const osc1 = this.ctx!.createOscillator();
      const osc2 = this.ctx!.createOscillator();
      const chordGain = this.ctx!.createGain();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(freq, now);
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(freq * 1.003, now); // Warm analog chorus detune

      const peak = (0.28 / freqs.length) * velocity;
      chordGain.gain.setValueAtTime(0.0001, now);
      chordGain.gain.linearRampToValueAtTime(peak, now + 0.04);
      chordGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.6);

      osc1.connect(chordGain);
      osc2.connect(chordGain);
      chordGain.connect(this.controllerGain!);

      osc1.start(now);
      osc1.stop(now + 1.7);
      osc2.start(now);
      osc2.stop(now + 1.7);
    });
  }

  private synth808Sub(freq: number, now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq * 1.6, now);
    osc.frequency.exponentialRampToValueAtTime(freq, now + 0.06);

    gain.gain.setValueAtTime(0.85 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.95);

    osc.connect(gain);
    gain.connect(this.controllerGain);

    osc.start(now);
    osc.stop(now + 1.0);
  }

  private synthElectroKick(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.08);

    gain.gain.setValueAtTime(1.1 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.controllerGain);

    osc.start(now);
    osc.stop(now + 0.36);
  }

  private synthElectroClap(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.createNoiseBuffer(0.25);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1100, now);
    filter.Q.setValueAtTime(2.2, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.7 * velocity, now);
    gain.gain.setValueAtTime(0.2 * velocity, now + 0.015);
    gain.gain.setValueAtTime(0.8 * velocity, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.controllerGain);

    noise.start(now);
    noise.stop(now + 0.24);
  }

  private synthElectroHat(now: number, velocity: number, open: boolean) {
    if (!this.ctx || !this.controllerGain) return;
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.createNoiseBuffer(open ? 0.35 : 0.06);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(8500, now);

    const gain = this.ctx.createGain();
    const decay = open ? 0.32 : 0.055;
    gain.gain.setValueAtTime(0.55 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.controllerGain);

    noise.start(now);
    noise.stop(now + decay + 0.01);
  }

  private synthLaserDrop(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200, now);
    osc.frequency.exponentialRampToValueAtTime(65, now + 0.25);

    gain.gain.setValueAtTime(0.5 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

    osc.connect(gain);
    gain.connect(this.controllerGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  private synthVocalChop(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const osc = this.ctx.createOscillator();
    const filter1 = this.ctx.createBiquadFilter();
    const filter2 = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(330, now);
    osc.frequency.linearRampToValueAtTime(392, now + 0.08);

    filter1.type = 'bandpass';
    filter1.frequency.setValueAtTime(750, now);
    filter1.Q.setValueAtTime(6.0, now);

    filter2.type = 'bandpass';
    filter2.frequency.setValueAtTime(1250, now);
    filter2.Q.setValueAtTime(5.0, now);

    gain.gain.setValueAtTime(0.65 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

    osc.connect(filter1);
    osc.connect(filter2);
    filter1.connect(gain);
    filter2.connect(gain);
    gain.connect(this.controllerGain);

    osc.start(now);
    osc.stop(now + 0.36);
  }

  private synthVinylScratch(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.createNoiseBuffer(0.18);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2400, now);
    filter.frequency.linearRampToValueAtTime(800, now + 0.1);
    filter.frequency.linearRampToValueAtTime(3200, now + 0.17);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.7 * velocity, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.controllerGain);

    noise.start(now);
    noise.stop(now + 0.19);
  }

  private synthBrassStab(now: number, velocity: number) {
    if (!this.ctx || !this.controllerGain) return;
    [349.23, 440.00, 523.25].forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const filter = this.ctx!.createBiquadFilter();
      const gain = this.ctx!.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq * (1 + (idx - 1) * 0.004), now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(4500, now + 0.06);
      filter.frequency.exponentialRampToValueAtTime(1200, now + 0.4);

      gain.gain.setValueAtTime(0.25 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.controllerGain!);

      osc.start(now);
      osc.stop(now + 0.46);
    });
  }

  // --- BACKING BEAT LOOPER ---
  public toggleBackingBeat(pattern: 'lofi' | 'house' | 'trap'): boolean {
    if (this.backingBeatPattern === pattern && this.backingBeatIntervalId !== null) {
      this.stopBackingBeat();
      return false;
    }
    this.startBackingBeat(pattern);
    return true;
  }

  public startBackingBeat(pattern: 'lofi' | 'house' | 'trap') {
    this.stopBackingBeat();
    this.backingBeatPattern = pattern;
    this.backingBeatStep = 0;

    const bpm = pattern === 'lofi' ? 86 : pattern === 'house' ? 124 : 140;
    const intervalMs = (60000 / bpm) / 4; // 16th notes

    this.backingBeatIntervalId = window.setInterval(() => {
      this.stepBackingBeat();
    }, intervalMs);
  }

  public stopBackingBeat() {
    if (this.backingBeatIntervalId !== null) {
      clearInterval(this.backingBeatIntervalId);
      this.backingBeatIntervalId = null;
    }
    this.backingBeatPattern = 'none';
  }

  public isBackingBeatActive(pattern?: string): boolean {
    if (pattern) {
      return this.backingBeatPattern === pattern && this.backingBeatIntervalId !== null;
    }
    return this.backingBeatIntervalId !== null;
  }

  public getBackingBeatPattern(): string {
    return this.backingBeatPattern;
  }

  private stepBackingBeat() {
    const step = this.backingBeatStep % 16;
    this.backingBeatStep++;

    if (this.backingBeatPattern === 'lofi') {
      // 86 BPM Chill Lo-Fi
      if (step === 0 || step === 10) this.playControllerPad(8, 0.75, false); // Kick
      if (step === 4 || step === 12) this.playControllerPad(9, 0.70, false); // Snare/Clap
      if (step % 2 === 0) this.playControllerPad(10, 0.5, false); // Closed Hat
      if (step === 0) this.playControllerPad(0, 0.45, false); // Cmaj7
      if (step === 8) this.playControllerPad(1, 0.45, false); // Am7
    } else if (this.backingBeatPattern === 'house') {
      // 124 BPM House Groove
      if (step % 4 === 0) this.playControllerPad(8, 0.9, false); // 4 on the floor Kick
      if (step === 4 || step === 12) this.playControllerPad(9, 0.75, false); // Clap
      if (step % 4 === 2) this.playControllerPad(11, 0.6, false); // Offbeat Open Hat
      if (step % 2 === 0 && step % 4 !== 2) this.playControllerPad(10, 0.35, false);
      if (step === 0) this.playControllerPad(2, 0.5, false); // Fmaj7
      if (step === 8) this.playControllerPad(3, 0.5, false); // G9
    } else if (this.backingBeatPattern === 'trap') {
      // 140 BPM Trap
      if (step === 0 || step === 6 || step === 10) this.playControllerPad(4, 0.85, false); // 808 Bass
      if (step === 8) this.playControllerPad(9, 0.8, false); // Halftime Snare
      this.playControllerPad(10, step % 4 === 0 ? 0.6 : 0.35, false); // Rolling Hats
    }
  }

  // --- FILTER & KNOB CONTROLS ---
  public setFilterCutoff(freq: number) {
    if (!this.controllerFilter || !this.ctx) return;
    const clamped = Math.max(200, Math.min(18000, freq));
    this.controllerFilter.frequency.setTargetAtTime(clamped, this.ctx.currentTime, 0.05);
  }

  public setControllerVolume(v: number) {
    this.settings.controllerVolume = Math.max(0, Math.min(1, v));
    if (this.controllerGain && this.ctx) {
      this.controllerGain.gain.setValueAtTime(this.settings.controllerVolume, this.ctx.currentTime);
    }
  }

  // --- SOUND FEEDBACK FOR VR UI ---
  public playUiClick() {
    this.init();
    this.resume();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(750, now);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.035);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.05);
  }

  // --- VOLUME CONTROLS ---
  public setMasterVolume(v: number) {
    this.settings.masterVolume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.settings.masterVolume, this.ctx.currentTime);
    }
  }

  public setGuitarVolume(v: number) {
    this.settings.guitarVolume = Math.max(0, Math.min(1, v));
    if (this.guitarGain && this.ctx) {
      this.guitarGain.gain.setValueAtTime(this.settings.guitarVolume, this.ctx.currentTime);
    }
  }

  public setDrumVolume(v: number) {
    this.settings.drumVolume = Math.max(0, Math.min(1, v));
    if (this.drumGain && this.ctx) {
      this.drumGain.gain.setValueAtTime(this.settings.drumVolume, this.ctx.currentTime);
    }
  }

  public getSettings(): AudioSettings {
    return { ...this.settings };
  }

  // --- REAL EVENT-BASED PERFORMANCE RECORDER ---
  public startRecording() {
    this.stopReplay();
    this.recordedEvents = [];
    this.isRecording = true;
    this.recordStartTime = performance.now();
    this.notifyRecorderState();
  }

  public stopRecording() {
    if (!this.isRecording) return;
    this.isRecording = false;
    this.notifyRecorderState();
  }

  public recordEvent(event: PerformanceEvent) {
    if (!this.isRecording) return;
    this.recordedEvents.push(event);
    this.notifyRecorderState();
  }

  public setReplayEventListener(cb: (event: PerformanceEvent) => void) {
    this.onReplayEventCallback = cb;
  }

  public startReplay(onEventTrigger?: (event: PerformanceEvent) => void) {
    if (this.recordedEvents.length === 0 || this.isPlaying) return;
    this.stopRecording();
    this.isPlaying = true;
    if (onEventTrigger) {
      this.onReplayEventCallback = onEventTrigger;
    }

    const totalDuration = this.getRecordedDuration();
    this.notifyRecorderState();

    this.recordedEvents.forEach(evt => {
      const timeoutId = window.setTimeout(() => {
        if (!this.isPlaying) return;

        // Trigger real instrument sound
        if (evt.type === 'guitar') {
          const stringIndex = parseInt(evt.id.replace('string_', ''), 10);
          this.playGuitarString(isNaN(stringIndex) ? 0 : stringIndex, evt.velocity, false);
        } else if (evt.type === 'drum') {
          this.playDrum(evt.id, evt.velocity, false);
        } else if (evt.type === 'controller') {
          const padIndex = parseInt(evt.id.replace('pad_', ''), 10);
          this.playControllerPad(isNaN(padIndex) ? 0 : padIndex, evt.velocity, false);
        }

        // Notify visual callback for string animation or drum head animation
        if (this.onReplayEventCallback) {
          this.onReplayEventCallback(evt);
        }
      }, evt.time);

      this.playbackTimeoutIds.push(timeoutId);
    });

    // Schedule finish
    const finishTimeout = window.setTimeout(() => {
      this.stopReplay();
    }, totalDuration + 200);
    this.playbackTimeoutIds.push(finishTimeout);
  }

  public stopReplay() {
    this.isPlaying = false;
    this.playbackTimeoutIds.forEach(id => clearTimeout(id));
    this.playbackTimeoutIds = [];
    this.notifyRecorderState();
  }

  public clearRecording() {
    this.stopReplay();
    this.stopRecording();
    this.recordedEvents = [];
    this.notifyRecorderState();
  }

  public getRecordedDuration(): number {
    if (this.recordedEvents.length === 0) return 0;
    return this.recordedEvents[this.recordedEvents.length - 1].time;
  }

  public getRecordedEventsCount(): number {
    return this.recordedEvents.length;
  }

  public getRecorderState(): RecorderState {
    return {
      isRecording: this.isRecording,
      isPlaying: this.isPlaying,
      startTime: this.recordStartTime,
      duration: this.getRecordedDuration(),
      events: [...this.recordedEvents],
      playbackProgress: 0,
    };
  }

  public setOnRecorderStateChange(cb: (state: RecorderState) => void) {
    this.onRecorderStateChange = cb;
  }

  private notifyRecorderState() {
    if (this.onRecorderStateChange) {
      this.onRecorderStateChange(this.getRecorderState());
    }
  }
}
