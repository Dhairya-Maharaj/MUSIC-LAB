import * as THREE from 'three';
import { VRSettings } from '../types';

export interface VRController {
  index: number;
  controller: THREE.XRTargetRaySpace;
  grip: THREE.XRGripSpace;
  rayLine: THREE.Line;
  reticle: THREE.Mesh;
  prevPosition: THREE.Vector3;
  currPosition: THREE.Vector3;
  isTriggerDown: boolean;
  isGripDown: boolean;
  gamepad: Gamepad | null;
  // Articulated VR motion controller parts
  triggerMesh: THREE.Mesh;
  gripButtonMesh: THREE.Mesh;
  thumbstickGroup: THREE.Group;
  primaryButtonMesh: THREE.Mesh;
  secondaryButtonMesh: THREE.Mesh;
  hudGroup: THREE.Group;
  showHud: boolean;
}

export class VRManager {
  public renderer: THREE.WebGLRenderer;
  public camera: THREE.PerspectiveCamera;
  public userRig: THREE.Group;
  public controllers: VRController[] = [];

  // Teleportation
  public isTeleporting: boolean = false;
  private teleportControllerIndex: number = 0;
  private teleportMarker: THREE.Mesh;
  private teleportRay: THREE.Line;
  private teleportTarget: THREE.Vector3 = new THREE.Vector3();
  private hasValidTeleportTarget: boolean = false;

  // Settings
  public settings: VRSettings;

  // Snap turn state
  private snapTurnCooldown: number = 0;
  private buttonToggleCooldown: number = 0;

  // Teleport collision objects (floor and rug)
  public floorObjects: THREE.Object3D[] = [];

  constructor(
    renderer: THREE.WebGLRenderer,
    camera: THREE.PerspectiveCamera,
    scene: THREE.Scene,
    settings: VRSettings
  ) {
    this.renderer = renderer;
    this.camera = camera;
    this.settings = settings;

    // Camera user rig (allows moving the player in the room)
    this.userRig = new THREE.Group();
    this.userRig.position.set(0, 0, 0.2); // Start standing facing the studio gear
    scene.add(this.userRig);
    this.userRig.add(camera);

    // Setup WebXR
    this.renderer.xr.enabled = true;

    // Teleport Marker
    const markerMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.8,
    });
    this.teleportMarker = new THREE.Mesh(new THREE.RingGeometry(0.18, 0.24, 32), markerMat);
    this.teleportMarker.rotation.x = -Math.PI / 2;
    this.teleportMarker.visible = false;
    scene.add(this.teleportMarker);

    // Teleport arc line
    const rayMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 });
    const rayGeom = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.teleportRay = new THREE.Line(rayGeom, rayMat);
    this.teleportRay.visible = false;
    scene.add(this.teleportRay);

    // Setup two VR controllers
    this.setupControllers(scene);
  }

  private createHudTexture(isRightHand: boolean): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Rounded card background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
    ctx.strokeStyle = isRightHand ? '#f43f5e' : '#38bdf8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(8, 8, 496, 240, 24);
    ctx.fill();
    ctx.stroke();

    // Top banner
    ctx.fillStyle = isRightHand ? '#f43f5e' : '#38bdf8';
    ctx.font = 'bold 26px sans-serif';
    ctx.fillText(isRightHand ? 'RIGHT CONTROLLER' : 'LEFT CONTROLLER', 28, 46);

    // Subtitle
    ctx.fillStyle = '#94a3b8';
    ctx.font = '16px sans-serif';
    ctx.fillText('6DOF Precision Motion Controller', 28, 72);

    // Key mappings
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px monospace';

    const mappings = isRightHand
      ? [
          '• [GRIP] Hold Guitar / Drumstick',
          '• [TRIGGER] Strum / Tap Pad / UI Laser',
          '• [THUMBSTICK] Snap Turn 45°',
          '• [A / B] Toggle Guide / Recenter',
        ]
      : [
          '• [GRIP] Hold Guitar Neck / Drumstick',
          '• [TRIGGER] Strum / Tap Pad / UI Laser',
          '• [THUMBSTICK] Push for Teleport Arc',
          '• [X / Y] Toggle Guide / Recenter',
        ];

    mappings.forEach((text, idx) => {
      ctx.fillText(text, 28, 114 + idx * 30);
    });

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    return texture;
  }

  private setupControllers(scene: THREE.Scene) {
    for (let i = 0; i < 2; i++) {
      const isRight = i === 1;
      const accentColor = isRight ? 0xf43f5e : 0x38bdf8;
      const controller = this.renderer.xr.getController(i);
      const grip = this.renderer.xr.getControllerGrip(i);

      this.userRig.add(controller);
      this.userRig.add(grip);

      // --- ARTICULATED VR CONTROLLER MODEL ---
      const ctrlRoot = new THREE.Group();
      grip.add(ctrlRoot);

      // 1. Ergonomic Handle Body
      const handleMat = new THREE.MeshStandardMaterial({
        color: 0x18181b,
        roughness: 0.5,
        metalness: 0.25,
      });
      const handleMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.015, 0.018, 0.11, 16),
        handleMat
      );
      handleMesh.position.set(0, -0.02, -0.012);
      handleMesh.rotation.x = -0.15;
      ctrlRoot.add(handleMesh);

      // Base cap of handle
      const baseCap = new THREE.Mesh(
        new THREE.SphereGeometry(0.018, 12, 12, 0, Math.PI * 2, 0, Math.PI * 0.5),
        handleMat
      );
      baseCap.position.set(0, -0.075, 0.005);
      baseCap.rotation.x = Math.PI;
      ctrlRoot.add(baseCap);

      // 2. Top Deck & Faceplate
      const deckMat = new THREE.MeshStandardMaterial({
        color: 0x27272a,
        roughness: 0.35,
        metalness: 0.6,
      });
      const deckMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.032, 0.026, 0.018, 24),
        deckMat
      );
      deckMesh.position.set(0, 0.038, -0.02);
      deckMesh.rotation.x = -0.28;
      ctrlRoot.add(deckMesh);

      // 3. Sensor Tracking Halo Arch
      const haloMat = new THREE.MeshStandardMaterial({
        color: 0x27272a,
        roughness: 0.4,
        metalness: 0.5,
      });
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.046, 0.0055, 12, 32, Math.PI * 1.55),
        haloMat
      );
      halo.position.set(isRight ? 0.012 : -0.012, 0.048, -0.036);
      halo.rotation.x = Math.PI / 2.6;
      halo.rotation.y = isRight ? -0.25 : 0.25;
      ctrlRoot.add(halo);

      // Glowing LED accent strip on Halo
      const ledStripMat = new THREE.MeshBasicMaterial({ color: accentColor });
      const ledStrip = new THREE.Mesh(
        new THREE.TorusGeometry(0.046, 0.002, 8, 28, Math.PI * 1.45),
        ledStripMat
      );
      ledStrip.position.copy(halo.position);
      ledStrip.rotation.copy(halo.rotation);
      ctrlRoot.add(ledStrip);

      // 4. Animated Index Trigger
      const triggerMat = new THREE.MeshStandardMaterial({
        color: 0x3f3f46,
        roughness: 0.3,
        metalness: 0.4,
      });
      const triggerMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.012, 0.024, 0.018),
        triggerMat
      );
      triggerMesh.position.set(0, 0.024, -0.036);
      ctrlRoot.add(triggerMesh);

      // 5. Animated Grip Squeeze Button
      const gripBtnMat = new THREE.MeshStandardMaterial({
        color: 0x3f3f46,
        roughness: 0.4,
        metalness: 0.3,
      });
      const gripButtonMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.008, 0.038, 0.014),
        gripBtnMat
      );
      const baseGripX = isRight ? -0.016 : 0.016;
      gripButtonMesh.position.set(baseGripX, -0.012, -0.015);
      ctrlRoot.add(gripButtonMesh);

      // 6. Animated Analog Thumbstick
      const thumbstickGroup = new THREE.Group();
      thumbstickGroup.position.set(isRight ? 0.009 : -0.009, 0.048, -0.022);
      ctrlRoot.add(thumbstickGroup);

      // Stick shaft
      const stickShaftMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8 });
      const stickShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.012, 12), stickShaftMat);
      stickShaft.position.y = 0.006;
      thumbstickGroup.add(stickShaft);

      // Stick concave thumb cap
      const stickCapMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.7 });
      const stickCap = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.008, 0.004, 16), stickCapMat);
      stickCap.position.y = 0.012;
      thumbstickGroup.add(stickCap);

      // 7. Face Buttons
      const btnMat = new THREE.MeshStandardMaterial({
        color: 0x52525b,
        roughness: 0.3,
        metalness: 0.5,
      });
      // Primary button (A on right, X on left)
      const primaryBtn = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.004, 16), btnMat);
      primaryBtn.position.set(isRight ? -0.01 : 0.01, 0.046, -0.015);
      primaryBtn.rotation.x = -0.28;
      ctrlRoot.add(primaryBtn);

      // Secondary button (B on right, Y on left)
      const secondaryBtn = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.004, 16), btnMat);
      secondaryBtn.position.set(isRight ? -0.005 : 0.005, 0.049, -0.028);
      secondaryBtn.rotation.x = -0.28;
      ctrlRoot.add(secondaryBtn);

      // 8. Holographic Controller HUD Tooltip Badge
      const hudGroup = new THREE.Group();
      hudGroup.position.set(0, 0.16, -0.04);

      const hudMat = new THREE.MeshBasicMaterial({
        map: this.createHudTexture(isRight),
        transparent: true,
        opacity: 0.95,
        side: THREE.DoubleSide,
      });
      const hudMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 0.09), hudMat);
      hudGroup.add(hudMesh);

      // Subtle glowing stem connecting HUD to controller
      const stemMat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.45 });
      const stemGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, -0.045, 0),
        new THREE.Vector3(0, -0.09, 0),
      ]);
      hudGroup.add(new THREE.Line(stemGeom, stemMat));

      ctrlRoot.add(hudGroup);

      // Pointer Ray Line
      const rayGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -2.5),
      ]);
      const rayLineMat = new THREE.LineBasicMaterial({
        color: accentColor,
        transparent: true,
        opacity: 0.5,
      });
      const rayLine = new THREE.Line(rayGeom, rayLineMat);
      controller.add(rayLine);

      // Reticle dot
      const reticleMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.85,
      });
      const reticle = new THREE.Mesh(new THREE.RingGeometry(0.012, 0.018, 16), reticleMat);
      reticle.position.set(0, 0, -2.5);
      controller.add(reticle);

      this.controllers.push({
        index: i,
        controller,
        grip,
        rayLine,
        reticle,
        prevPosition: new THREE.Vector3(),
        currPosition: new THREE.Vector3(),
        isTriggerDown: false,
        isGripDown: false,
        gamepad: null,
        triggerMesh,
        gripButtonMesh,
        thumbstickGroup,
        primaryButtonMesh: primaryBtn,
        secondaryButtonMesh: secondaryBtn,
        hudGroup,
        showHud: true,
      });
    }
  }

  /**
   * Send haptic vibration pulse to VR controller
   */
  public triggerHaptic(controllerIndex: number, intensity: number = 0.5, durationMs: number = 40) {
    const ctrl = this.controllers[controllerIndex];
    if (!ctrl) return;

    const session = this.renderer.xr.getSession();
    if (!session || !session.inputSources) return;

    const inputSource = session.inputSources[controllerIndex];
    if (!inputSource || !inputSource.gamepad) return;

    const gamepad = inputSource.gamepad;

    // WebXR standard haptic actuators
    if (gamepad.hapticActuators && gamepad.hapticActuators.length > 0) {
      gamepad.hapticActuators[0].pulse(Math.min(1.0, intensity), durationMs);
    } else if (gamepad.vibrationActuator) {
      // Chrome/Meta Quest vibration actuator fallback
      (gamepad.vibrationActuator as unknown as {
        playEffect: (type: string, options: { duration: number; strongMagnitude: number; weakMagnitude: number }) => void;
      }).playEffect('dual-rumble', {
        duration: durationMs,
        strongMagnitude: intensity,
        weakMagnitude: intensity * 0.8,
      });
    }
  }

  /**
   * Frame update for VR locomotion, controllers, and input
   */
  public update(
    delta: number,
    onTriggerDown?: (ctrlIndex: number, worldPos: THREE.Vector3, worldRay: THREE.Ray) => void,
    onGripDown?: (ctrlIndex: number, worldPos: THREE.Vector3) => void,
    onGripUp?: (ctrlIndex: number, worldPos: THREE.Vector3) => void
  ) {
    if (this.snapTurnCooldown > 0) {
      this.snapTurnCooldown -= delta;
    }

    const session = this.renderer.xr.getSession();
    if (!session) return;

    const inputSources = session.inputSources;

    for (let i = 0; i < this.controllers.length; i++) {
      const c = this.controllers[i];
      const inputSource = inputSources[i];
      if (!inputSource) continue;

      c.gamepad = inputSource.gamepad;

      // Track world positions
      const worldPos = new THREE.Vector3();
      c.controller.getWorldPosition(worldPos);
      c.prevPosition.copy(c.currPosition);
      c.currPosition.copy(worldPos);

      // Gamepad Buttons
      if (c.gamepad) {
        const buttons = c.gamepad.buttons;
        const axes = c.gamepad.axes;

        // Button 0 = Trigger
        const triggerPressed = buttons[0] && buttons[0].pressed;
        if (triggerPressed && !c.isTriggerDown) {
          c.isTriggerDown = true;
          this.triggerHaptic(i, 0.4, 20);

          // Get ray in world space
          const ray = new THREE.Ray();
          c.controller.getWorldPosition(ray.origin);
          c.controller.getWorldDirection(ray.direction);
          ray.direction.negate(); // In Three.js targetRay points along -Z

          if (onTriggerDown) onTriggerDown(i, worldPos, ray);
        } else if (!triggerPressed && c.isTriggerDown) {
          c.isTriggerDown = false;
        }

        // Button 1 = Grip
        const gripPressed = buttons[1] && buttons[1].pressed;
        if (gripPressed && !c.isGripDown) {
          c.isGripDown = true;
          this.triggerHaptic(i, 0.6, 35);
          if (onGripDown) onGripDown(i, worldPos);
        } else if (!gripPressed && c.isGripDown) {
          c.isGripDown = false;
          if (onGripUp) onGripUp(i, worldPos);
        }

        // Handedness detection from WebXR inputSource
        const handedness = inputSource.handedness;
        const isRightHand = handedness === 'right' || (handedness !== 'left' && i === 1);
        const isLeftHand = handedness === 'left' || (handedness !== 'right' && i === 0);

        // WebXR Standard Gamepad Thumbstick axes mapping:
        // xr-standard: axes[0] = X, axes[1] = Y (-1 is forward, +1 is backward)
        let rawX = axes[0] ?? 0;
        let rawY = axes[1] ?? 0;

        // Fallback for non-standard runtimes where axes 0 & 1 are absent and 2 & 3 are thumbsticks
        if (axes.length >= 4 && Math.abs(rawX) < 0.05 && Math.abs(rawY) < 0.05) {
          if (Math.abs(axes[2] ?? 0) > 0.1 || Math.abs(axes[3] ?? 0) > 0.1) {
            rawX = axes[2];
            rawY = axes[3];
          }
        }

        // Strict 0.20 deadzone to eliminate stick drift, capacitive sensor noise, and ghost backward sliding
        const stickMag = Math.hypot(rawX, rawY);
        let stickX = 0;
        let stickY = 0;
        if (stickMag > 0.20) {
          const norm = Math.min(1.0, (stickMag - 0.20) / (1.0 - 0.20));
          stickX = (rawX / stickMag) * norm;
          stickY = (rawY / stickMag) * norm;
        }

        // --- Turning on Right Controller ---
        if (isRightHand && Math.abs(stickX) > 0.40) {
          if (this.settings.turnMode === 'snap') {
            if (this.snapTurnCooldown <= 0 && Math.abs(stickX) > 0.60) {
              const sign = stickX > 0 ? -1 : 1;
              const snapAngle = THREE.MathUtils.degToRad(this.settings.snapAngle || 45);
              this.userRig.rotation.y += sign * snapAngle;
              this.snapTurnCooldown = 0.35; // 350ms cooldown between snap turns
              this.triggerHaptic(i, 0.3, 15);
            }
          } else {
            // Smooth turn
            const turnSpeed = this.settings.turnSpeed || 1.8;
            this.userRig.rotation.y -= stickX * turnSpeed * delta;
          }
        }

        // --- Locomotion on Left Controller ---
        if (isLeftHand) {
          if (this.settings.movementMode === 'smooth') {
            if (Math.abs(stickY) > 0.01 || Math.abs(stickX) > 0.01) {
              // Direction relative to HMD headset gaze
              const forward = new THREE.Vector3();
              this.camera.getWorldDirection(forward);
              forward.y = 0;
              if (forward.lengthSq() < 0.001) forward.set(0, 0, -1);
              forward.normalize();

              const right = new THREE.Vector3();
              right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

              const moveSpeed = 2.0;
              // WebXR standard: stickY < 0 is pushed forward -> -stickY is positive -> move forward!
              const moveVector = forward
                .clone()
                .multiplyScalar(-stickY * moveSpeed * delta)
                .add(right.clone().multiplyScalar(stickX * moveSpeed * delta));

              this.userRig.position.add(moveVector);

              // Constrain within safe studio bounds
              this.userRig.position.x = Math.max(-2.6, Math.min(2.6, this.userRig.position.x));
              this.userRig.position.z = Math.max(-3.0, Math.min(2.0, this.userRig.position.z));
            }
          } else {
            // Teleport mode: push thumbstick forward to aim, release to teleport
            if (stickY < -0.55) {
              this.updateTeleportArc(c);
            } else if (this.isTeleporting) {
              this.executeTeleport();
            }
          }
        }

        // --- ARTICULATED CONTROLLER COMPONENT ANIMATION ---
        const triggerVal = buttons[0] ? buttons[0].value || (buttons[0].pressed ? 1 : 0) : 0;
        c.triggerMesh.rotation.x = -triggerVal * 0.45;

        const gripVal = buttons[1] ? buttons[1].value || (buttons[1].pressed ? 1 : 0) : 0;
        const baseGripX = i === 1 ? -0.016 : 0.016;
        c.gripButtonMesh.position.x = baseGripX + (i === 1 ? -1 : 1) * (gripVal * 0.0035);

        c.thumbstickGroup.rotation.x = -stickY * 0.38;
        c.thumbstickGroup.rotation.z = stickX * 0.38;
        const stickDown = buttons[3] && buttons[3].pressed;
        c.thumbstickGroup.position.y = stickDown ? 0.045 : 0.048;

        const primaryPressed = !!(buttons[4] && buttons[4].pressed);
        const secondaryPressed = !!(buttons[5] && buttons[5].pressed);
        c.primaryButtonMesh.position.y = primaryPressed ? 0.044 : 0.046;
        c.secondaryButtonMesh.position.y = secondaryPressed ? 0.047 : 0.049;

        // Toggle Controller HUD guide on A / X press
        if ((primaryPressed || secondaryPressed) && this.buttonToggleCooldown <= 0) {
          this.buttonToggleCooldown = 0.4;
          c.showHud = !c.showHud;
          c.hudGroup.visible = c.showHud;
          this.triggerHaptic(i, 0.3, 20);
        }

        // Orient holographic HUD to face player's head
        if (c.hudGroup.visible) {
          const worldCamPos = new THREE.Vector3();
          this.camera.getWorldPosition(worldCamPos);
          c.hudGroup.lookAt(worldCamPos);
        }
      }
    }
  }

  private updateTeleportArc(ctrl: VRController) {
    this.isTeleporting = true;
    this.teleportControllerIndex = ctrl.index;

    // Raycast from controller forward down onto floor
    const ray = new THREE.Ray();
    ctrl.controller.getWorldPosition(ray.origin);
    ctrl.controller.getWorldDirection(ray.direction);
    ray.direction.negate();

    // Intersect floor plane (y = 0)
    const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const target = new THREE.Vector3();
    const hit = ray.intersectPlane(floorPlane, target);

    if (hit && target.distanceTo(ray.origin) < 7.0) {
      // Constrain to walkable studio bounds
      target.x = Math.max(-2.8, Math.min(2.8, target.x));
      target.z = Math.max(-3.4, Math.min(3.4, target.z));
      target.y = 0.01;

      this.teleportTarget.copy(target);
      this.hasValidTeleportTarget = true;

      this.teleportMarker.position.copy(target);
      this.teleportMarker.visible = true;

      // Update arc line points
      const points = [ray.origin.clone(), target.clone()];
      this.teleportRay.geometry.setFromPoints(points);
      this.teleportRay.visible = true;
    } else {
      this.hasValidTeleportTarget = false;
      this.teleportMarker.visible = false;
      this.teleportRay.visible = false;
    }
  }

  private executeTeleport() {
    this.isTeleporting = false;
    this.teleportMarker.visible = false;
    this.teleportRay.visible = false;

    if (this.hasValidTeleportTarget) {
      // Calculate offset so headset lands on target
      const headOffset = new THREE.Vector3();
      this.camera.getWorldPosition(headOffset);
      headOffset.sub(this.userRig.position);
      headOffset.y = 0;

      this.userRig.position.copy(this.teleportTarget).sub(headOffset);
      this.userRig.position.y = 0;

      this.triggerHaptic(this.teleportControllerIndex, 0.7, 40);
      this.hasValidTeleportTarget = false;
    }
  }

  public recenter() {
    this.userRig.position.set(0, 0, 0.2);
    this.userRig.rotation.set(0, 0, 0);
  }
}
