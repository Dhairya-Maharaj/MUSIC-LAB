import * as THREE from 'three';
import { AudioSettings, RecorderState, VRSettings } from '../types';
import { SoundEngine } from '../audio/soundEngine';

export interface UIButton {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  color?: string;
  activeColor?: string;
  isToggle?: boolean;
  isActive?: boolean;
  onClick: () => void;
}

export class VRStudioUiPanel {
  public group: THREE.Group;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private texture: THREE.CanvasTexture;
  private panelMesh: THREE.Mesh;
  private buttons: UIButton[] = [];
  private hoveredButtonId: string | null = null;
  private soundEngine: SoundEngine;

  // External states
  private recorderState: RecorderState;
  private audioSettings: AudioSettings;
  private vrSettings: VRSettings;
  private onSettingChange: (key: string, value: unknown) => void;

  constructor(
    soundEngine: SoundEngine,
    audioSettings: AudioSettings,
    vrSettings: VRSettings,
    onSettingChange: (key: string, value: unknown) => void
  ) {
    this.soundEngine = soundEngine;
    this.audioSettings = audioSettings;
    this.vrSettings = vrSettings;
    this.onSettingChange = onSettingChange;
    this.recorderState = soundEngine.getRecorderState();

    this.group = new THREE.Group();

    // Canvas setup (high DPI for sharp text in VR)
    this.canvas = document.createElement('canvas');
    this.canvas.width = 1024;
    this.canvas.height = 768;
    this.ctx = this.canvas.getContext('2d')!;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.minFilter = THREE.LinearFilter;

    // Panel 3D mesh
    const geometry = new THREE.PlaneGeometry(1.2, 0.9);
    const material = new THREE.MeshBasicMaterial({
      map: this.texture,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.98,
    });
    this.panelMesh = new THREE.Mesh(geometry, material);
    this.panelMesh.name = 'vr_ui_panel_mesh';

    // Stylish dark glass frame backing
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      metalness: 0.8,
      roughness: 0.2,
    });
    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.24, 0.94, 0.02), frameMat);
    frame.position.z = -0.012;

    // Stand pole
    const standMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.8, roughness: 0.3 });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.2, 12), standMat);
    pole.position.set(0, -0.6, -0.02);

    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.03, 16), standMat);
    base.position.set(0, -1.2, -0.02);

    this.group.add(frame);
    this.group.add(this.panelMesh);
    this.group.add(pole);
    this.group.add(base);

    // Position in studio
    this.group.position.set(0, 1.35, -2.1);

    this.initButtons();
    this.draw();

    // Listen to recorder updates
    this.soundEngine.setOnRecorderStateChange(state => {
      this.recorderState = state;
      this.draw();
    });
  }

  private initButtons() {
    this.buttons = [];

    // --- Performance Recorder Buttons ---
    // Record
    this.buttons.push({
      id: 'rec_record',
      x: 60,
      y: 190,
      w: 200,
      h: 56,
      label: '● RECORD',
      color: '#dc2626',
      activeColor: '#ef4444',
      onClick: () => {
        if (this.recorderState.isRecording) {
          this.soundEngine.stopRecording();
        } else {
          this.soundEngine.startRecording();
        }
      },
    });

    // Stop
    this.buttons.push({
      id: 'rec_stop',
      x: 280,
      y: 190,
      w: 180,
      h: 56,
      label: '■ STOP',
      color: '#475569',
      activeColor: '#64748b',
      onClick: () => {
        this.soundEngine.stopRecording();
        this.soundEngine.stopReplay();
      },
    });

    // Replay
    this.buttons.push({
      id: 'rec_replay',
      x: 480,
      y: 190,
      w: 240,
      h: 56,
      label: '▶ REPLAY',
      color: '#16a34a',
      activeColor: '#22c55e',
      onClick: () => {
        if (this.recorderState.isPlaying) {
          this.soundEngine.stopReplay();
        } else {
          this.soundEngine.startReplay();
        }
      },
    });

    // Clear
    this.buttons.push({
      id: 'rec_clear',
      x: 740,
      y: 190,
      w: 180,
      h: 56,
      label: '✕ CLEAR',
      color: '#334155',
      activeColor: '#475569',
      onClick: () => {
        this.soundEngine.clearRecording();
      },
    });

    // --- Volume Controls ---
    // Master Volume (- / +)
    this.buttons.push({
      id: 'vol_master_down',
      x: 60,
      y: 350,
      w: 60,
      h: 46,
      label: '−',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.max(0, this.audioSettings.masterVolume - 0.1);
        this.audioSettings.masterVolume = v;
        this.soundEngine.setMasterVolume(v);
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vol_master_up',
      x: 420,
      y: 350,
      w: 60,
      h: 46,
      label: '+',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.min(1.0, this.audioSettings.masterVolume + 0.1);
        this.audioSettings.masterVolume = v;
        this.soundEngine.setMasterVolume(v);
        this.draw();
      },
    });

    // Controller Volume (- / +)
    this.buttons.push({
      id: 'vol_controller_down',
      x: 60,
      y: 440,
      w: 60,
      h: 46,
      label: '−',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.max(0, this.audioSettings.controllerVolume - 0.1);
        this.audioSettings.controllerVolume = v;
        this.soundEngine.setControllerVolume(v);
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vol_controller_up',
      x: 420,
      y: 440,
      w: 60,
      h: 46,
      label: '+',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.min(1.0, this.audioSettings.controllerVolume + 0.1);
        this.audioSettings.controllerVolume = v;
        this.soundEngine.setControllerVolume(v);
        this.draw();
      },
    });

    // Guitar Volume (- / +)
    this.buttons.push({
      id: 'vol_guitar_down',
      x: 540,
      y: 350,
      w: 60,
      h: 46,
      label: '−',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.max(0, this.audioSettings.guitarVolume - 0.1);
        this.audioSettings.guitarVolume = v;
        this.soundEngine.setGuitarVolume(v);
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vol_guitar_up',
      x: 900,
      y: 350,
      w: 60,
      h: 46,
      label: '+',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.min(1.0, this.audioSettings.guitarVolume + 0.1);
        this.audioSettings.guitarVolume = v;
        this.soundEngine.setGuitarVolume(v);
        this.draw();
      },
    });

    // Drum Volume (- / +)
    this.buttons.push({
      id: 'vol_drum_down',
      x: 540,
      y: 440,
      w: 60,
      h: 46,
      label: '−',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.max(0, this.audioSettings.drumVolume - 0.1);
        this.audioSettings.drumVolume = v;
        this.soundEngine.setDrumVolume(v);
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vol_drum_up',
      x: 900,
      y: 440,
      w: 60,
      h: 46,
      label: '+',
      color: '#1e293b',
      activeColor: '#334155',
      onClick: () => {
        const v = Math.min(1.0, this.audioSettings.drumVolume + 0.1);
        this.audioSettings.drumVolume = v;
        this.soundEngine.setDrumVolume(v);
        this.draw();
      },
    });

    // --- Locomotion & VR Settings ---
    // Locomotion mode: Teleport vs Smooth Walk
    this.buttons.push({
      id: 'vr_loco_teleport',
      x: 60,
      y: 570,
      w: 200,
      h: 48,
      label: 'Teleport (Comfort)',
      color: this.vrSettings.movementMode === 'teleport' ? '#2563eb' : '#1e293b',
      onClick: () => {
        this.vrSettings.movementMode = 'teleport';
        this.onSettingChange('movementMode', 'teleport');
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vr_loco_smooth',
      x: 280,
      y: 570,
      w: 200,
      h: 48,
      label: 'Smooth Walk',
      color: this.vrSettings.movementMode === 'smooth' ? '#2563eb' : '#1e293b',
      onClick: () => {
        this.vrSettings.movementMode = 'smooth';
        this.onSettingChange('movementMode', 'smooth');
        this.draw();
      },
    });

    // Turn mode: Snap 45 vs Smooth Turn
    this.buttons.push({
      id: 'vr_turn_snap',
      x: 540,
      y: 570,
      w: 190,
      h: 48,
      label: 'Snap Turn 45°',
      color: this.vrSettings.turnMode === 'snap' ? '#2563eb' : '#1e293b',
      onClick: () => {
        this.vrSettings.turnMode = 'snap';
        this.onSettingChange('turnMode', 'snap');
        this.draw();
      },
    });
    this.buttons.push({
      id: 'vr_turn_smooth',
      x: 750,
      y: 570,
      w: 190,
      h: 48,
      label: 'Smooth Turn',
      color: this.vrSettings.turnMode === 'smooth' ? '#2563eb' : '#1e293b',
      onClick: () => {
        this.vrSettings.turnMode = 'smooth';
        this.onSettingChange('turnMode', 'smooth');
        this.draw();
      },
    });

    // Handedness Toggle
    this.buttons.push({
      id: 'vr_hand_toggle',
      x: 60,
      y: 670,
      w: 300,
      h: 48,
      label: this.vrSettings.leftHanded ? 'Guitar: Left-Handed' : 'Guitar: Right-Handed',
      color: '#3b82f6',
      onClick: () => {
        this.vrSettings.leftHanded = !this.vrSettings.leftHanded;
        this.onSettingChange('leftHanded', this.vrSettings.leftHanded);
        this.draw();
      },
    });

    // Recenter room
    this.buttons.push({
      id: 'vr_recenter',
      x: 750,
      y: 670,
      w: 190,
      h: 48,
      label: 'Reset Origin',
      color: '#475569',
      onClick: () => {
        this.onSettingChange('recenter', true);
      },
    });
  }

  public draw() {
    const ctx = this.ctx;
    const w = 1024;
    const h = 768;

    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, w, h);

    // Top Header Banner
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, w, 84);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 34px sans-serif';
    ctx.fillText('VR MUSIC STUDIO CONSOLE', 40, 54);

    // Live status badge
    let badgeText = 'STATUS: READY';
    let badgeBg = '#1e3a8a';
    if (this.recorderState.isRecording) {
      badgeText = '● RECORDING LIVE';
      badgeBg = '#991b1b';
    } else if (this.recorderState.isPlaying) {
      badgeText = '▶ REPLAYING PERFORMANCE';
      badgeBg = '#166534';
    }

    ctx.fillStyle = badgeBg;
    ctx.roundRect(660, 20, 320, 44, 8);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText(badgeText, 680, 49);

    // --- Section 1: Performance Recorder ---
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('EVENT-BASED PERFORMANCE RECORDER', 40, 130);

    const durSec = (this.recorderState.duration / 1000).toFixed(1);
    ctx.font = '20px sans-serif';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(
      `Recorded Events: ${this.recorderState.events.length} | Length: ${durSec}s`,
      40,
      165
    );

    // --- Section 2: Audio Mixing ---
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('AUDIO MIXER & VOLUME', 40, 305);

    // Master volume bar
    ctx.font = '18px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('Master Volume', 60, 338);

    ctx.fillStyle = '#334155';
    ctx.roundRect(140, 355, 260, 36, 6);
    ctx.fill();

    const masterPercent = this.audioSettings.masterVolume;
    ctx.fillStyle = '#38bdf8';
    ctx.roundRect(142, 357, (260 - 4) * masterPercent, 32, 4);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText(`${Math.round(masterPercent * 100)}%`, 250, 380);

    // Controller Volume bar
    ctx.font = '18px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('Controller Pads Volume', 60, 428);

    ctx.fillStyle = '#334155';
    ctx.roundRect(140, 445, 260, 36, 6);
    ctx.fill();

    const ctrlPercent = this.audioSettings.controllerVolume || 0.85;
    ctx.fillStyle = '#a855f7';
    ctx.roundRect(142, 447, (260 - 4) * ctrlPercent, 32, 4);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText(`${Math.round(ctrlPercent * 100)}%`, 250, 470);

    // Guitar volume bar
    ctx.font = '18px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('Acoustic Guitar Volume', 540, 338);

    ctx.fillStyle = '#334155';
    ctx.roundRect(620, 355, 260, 36, 6);
    ctx.fill();

    const guitarPercent = this.audioSettings.guitarVolume;
    ctx.fillStyle = '#f59e0b';
    ctx.roundRect(622, 357, (260 - 4) * guitarPercent, 32, 4);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText(`${Math.round(guitarPercent * 100)}%`, 730, 380);

    // Drum volume bar
    ctx.font = '18px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('Drum Kit Volume', 540, 428);

    ctx.fillStyle = '#334155';
    ctx.roundRect(620, 445, 260, 36, 6);
    ctx.fill();

    const drumPercent = this.audioSettings.drumVolume;
    ctx.fillStyle = '#10b981';
    ctx.roundRect(622, 447, (260 - 4) * drumPercent, 32, 4);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText(`${Math.round(drumPercent * 100)}%`, 730, 470);

    // --- Section 3: VR Comfort & Locomotion Settings ---
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('VR MOVEMENT & CONTROLLER SETTINGS', 40, 535);

    // Draw buttons
    this.buttons.forEach(btn => {
      const isHover = btn.id === this.hoveredButtonId;

      // Dynamic labels
      if (btn.id === 'rec_record') {
        btn.label = this.recorderState.isRecording ? '■ STOP RECORD' : '● RECORD';
        btn.color = this.recorderState.isRecording ? '#991b1b' : '#dc2626';
      } else if (btn.id === 'rec_replay') {
        btn.label = this.recorderState.isPlaying ? '■ STOP REPLAY' : '▶ REPLAY';
        btn.color = this.recorderState.isPlaying ? '#15803d' : '#16a34a';
      } else if (btn.id === 'vr_loco_teleport') {
        btn.color = this.vrSettings.movementMode === 'teleport' ? '#2563eb' : '#1e293b';
      } else if (btn.id === 'vr_loco_smooth') {
        btn.color = this.vrSettings.movementMode === 'smooth' ? '#2563eb' : '#1e293b';
      } else if (btn.id === 'vr_turn_snap') {
        btn.color = this.vrSettings.turnMode === 'snap' ? '#2563eb' : '#1e293b';
      } else if (btn.id === 'vr_turn_smooth') {
        btn.color = this.vrSettings.turnMode === 'smooth' ? '#2563eb' : '#1e293b';
      } else if (btn.id === 'vr_hand_toggle') {
        btn.label = this.vrSettings.leftHanded ? 'Guitar: Left-Handed' : 'Guitar: Right-Handed';
      }

      ctx.fillStyle = isHover ? (btn.activeColor || '#38bdf8') : (btn.color || '#334155');
      ctx.roundRect(btn.x, btn.y, btn.w, btn.h, 8);
      ctx.fill();

      // Border highlight on hover
      if (isHover) {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      ctx.font = 'bold 20px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
    });

    this.texture.needsUpdate = true;
  }

  /**
   * Handle raycast intersection from VR controller
   * uv is (0,0) bottom-left to (1,1) top-right on plane
   */
  public handleRaycast(uv: THREE.Vector2): UIButton | null {
    // Map UV to canvas coordinates (UV (0,0) is bottom-left, canvas (0,0) is top-left)
    const canvasX = uv.x * 1024;
    const canvasY = (1 - uv.y) * 768;

    let hitBtn: UIButton | null = null;
    for (const btn of this.buttons) {
      if (
        canvasX >= btn.x &&
        canvasX <= btn.x + btn.w &&
        canvasY >= btn.y &&
        canvasY <= btn.y + btn.h
      ) {
        hitBtn = btn;
        break;
      }
    }

    const newHoverId = hitBtn ? hitBtn.id : null;
    if (newHoverId !== this.hoveredButtonId) {
      this.hoveredButtonId = newHoverId;
      this.draw();
    }

    return hitBtn;
  }

  public clearHover() {
    if (this.hoveredButtonId !== null) {
      this.hoveredButtonId = null;
      this.draw();
    }
  }

  public clickButton(btn: UIButton) {
    this.soundEngine.playUiClick();
    btn.onClick();
    this.draw();
  }

  public getMesh(): THREE.Mesh {
    return this.panelMesh;
  }
}
