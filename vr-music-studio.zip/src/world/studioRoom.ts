import * as THREE from 'three';

export class StudioRoom {
  public group: THREE.Group;
  public leftSpeakerWoofer!: THREE.Mesh;
  public rightSpeakerWoofer!: THREE.Mesh;
  public micGroup: THREE.Group;
  public floorMesh!: THREE.Mesh;
  public rugMesh!: THREE.Mesh;

  constructor() {
    this.group = new THREE.Group();
    this.micGroup = new THREE.Group();

    this.buildRoom();
    this.buildAcousticPanels();
    this.buildLighting();
    this.buildSpeakers();
    this.buildMicrophone();
  }

  private buildRoom() {
    // Room dimensions: 7m wide, 3.4m tall, 8m deep
    const roomWidth = 7.0;
    const roomHeight = 3.4;
    const roomDepth = 8.0;

    // Hardwood floor (warm dark walnut)
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x3e2817,
      roughness: 0.4,
      metalness: 0.1,
    });
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(roomWidth, roomDepth), floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    floor.name = 'teleport_floor'; // Target for VR teleportation!
    this.floorMesh = floor;
    this.group.add(floor);

    // Studio Area Rug (under guitar and drums)
    const rugMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b, // Dark charcoal studio rug
      roughness: 0.9,
    });
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(4.8, 4.2), rugMat);
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, 0.003, -1.4);
    rug.receiveShadow = true;
    rug.name = 'teleport_floor_rug';
    this.rugMesh = rug;
    this.group.add(rug);

    // Rug border accent
    const rugBorderMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.8 });
    const rugBorder = new THREE.Mesh(new THREE.RingGeometry(2.3, 2.35, 4), rugBorderMat);
    rugBorder.rotation.x = -Math.PI / 2;
    rugBorder.rotation.z = Math.PI / 4;
    rugBorder.position.set(0, 0.004, -1.4);
    this.group.add(rugBorder);

    // Ceiling (dark acoustic baffle panels)
    const ceilingMat = new THREE.MeshStandardMaterial({
      color: 0x111317,
      roughness: 0.9,
    });
    const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(roomWidth, roomDepth), ceilingMat);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.y = roomHeight;
    this.group.add(ceiling);

    // Walls (deep navy/slate studio walls)
    const wallMat = new THREE.MeshStandardMaterial({
      color: 0x181e28,
      roughness: 0.85,
    });

    // Back wall (behind instruments)
    const backWall = new THREE.Mesh(new THREE.PlaneGeometry(roomWidth, roomHeight), wallMat);
    backWall.position.set(0, roomHeight / 2, -roomDepth / 2);
    this.group.add(backWall);

    // Front wall (behind player start)
    const frontWall = new THREE.Mesh(new THREE.PlaneGeometry(roomWidth, roomHeight), wallMat);
    frontWall.rotation.y = Math.PI;
    frontWall.position.set(0, roomHeight / 2, roomDepth / 2);
    this.group.add(frontWall);

    // Left wall
    const leftWall = new THREE.Mesh(new THREE.PlaneGeometry(roomDepth, roomHeight), wallMat);
    leftWall.rotation.y = Math.PI / 2;
    leftWall.position.set(-roomWidth / 2, roomHeight / 2, 0);
    this.group.add(leftWall);

    // Right wall
    const rightWall = new THREE.Mesh(new THREE.PlaneGeometry(roomDepth, roomHeight), wallMat);
    rightWall.rotation.y = -Math.PI / 2;
    rightWall.position.set(roomWidth / 2, roomHeight / 2, 0);
    this.group.add(rightWall);
  }

  private buildAcousticPanels() {
    // Wood slat acoustic panels on back wall
    const slatMat = new THREE.MeshStandardMaterial({
      color: 0xa16207, // Warm teak wood slats
      roughness: 0.4,
    });
    const feltBackMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      roughness: 0.95,
    });

    // Acoustic diffuser frame on back wall
    const diffuserWidth = 4.2;
    const diffuserHeight = 2.4;
    const feltBack = new THREE.Mesh(
      new THREE.PlaneGeometry(diffuserWidth, diffuserHeight),
      feltBackMat
    );
    feltBack.position.set(0, 1.6, -3.98);
    this.group.add(feltBack);

    // 24 vertical wooden slats
    const numSlats = 24;
    for (let i = 0; i < numSlats; i++) {
      const x = -diffuserWidth / 2 + (i + 0.5) * (diffuserWidth / numSlats);
      const slat = new THREE.Mesh(
        new THREE.BoxGeometry(0.045, diffuserHeight - 0.1, 0.025),
        slatMat
      );
      slat.position.set(x, 1.6, -3.96);
      this.group.add(slat);
    }

    // Studio neon back-glow strip behind diffuser
    const neonMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const neonStripTop = new THREE.Mesh(new THREE.BoxGeometry(diffuserWidth, 0.02, 0.02), neonMat);
    neonStripTop.position.set(0, 2.82, -3.95);
    this.group.add(neonStripTop);

    // Geometric acoustic foam tiles on side walls
    const foamMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.9,
    });
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 6; col++) {
        // Left wall tiles
        const tileL = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.45, 0.45), foamMat);
        tileL.position.set(-3.48, 1.0 + row * 0.55, -2.0 + col * 0.55);
        this.group.add(tileL);

        // Right wall tiles
        const tileR = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.45, 0.45), foamMat);
        tileR.position.set(3.48, 1.0 + row * 0.55, -2.0 + col * 0.55);
        this.group.add(tileR);
      }
    }
  }

  private buildLighting() {
    // Ambient light: warm studio mood
    const ambientLight = new THREE.AmbientLight(0xfff5ea, 0.7);
    this.group.add(ambientLight);

    // Ceiling spotlight over Drums
    const drumSpot = new THREE.SpotLight(0xffedd5, 2.8, 10, Math.PI / 4, 0.4);
    drumSpot.position.set(1.3, 3.2, -1.6);
    drumSpot.target.position.set(1.3, 0.6, -1.6);
    this.group.add(drumSpot);
    this.group.add(drumSpot.target);

    // Ceiling spotlight over Guitar area
    const guitarSpot = new THREE.SpotLight(0xffedd5, 2.6, 10, Math.PI / 4, 0.4);
    guitarSpot.position.set(-1.4, 3.2, -1.4);
    guitarSpot.target.position.set(-1.4, 0.6, -1.4);
    this.group.add(guitarSpot);
    this.group.add(guitarSpot.target);

    // Center warm room light
    const centerPoint = new THREE.PointLight(0x38bdf8, 0.8, 8);
    centerPoint.position.set(0, 3.0, -1.0);
    this.group.add(centerPoint);

    // Track lighting rails along ceiling
    const trackMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8 });
    const trackRail1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 6.0), trackMat);
    trackRail1.position.set(-1.5, 3.36, 0);
    this.group.add(trackRail1);

    const trackRail2 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 6.0), trackMat);
    trackRail2.position.set(1.5, 3.36, 0);
    this.group.add(trackRail2);
  }

  private buildSpeakers() {
    const speakerPositions = [
      { x: -2.3, y: 1.25, z: -2.8, rotY: 0.3 }, // Left monitor
      { x: 2.3, y: 1.25, z: -2.8, rotY: -0.3 }, // Right monitor
    ];

    const speakerCabMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.35,
    });
    const standMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      metalness: 0.8,
      roughness: 0.3,
    });
    const yellowConeMat = new THREE.MeshStandardMaterial({
      color: 0xeab308, // Kevlar yellow woofer cone like high-end KRK studio monitors
      roughness: 0.4,
    });
    const tweeterMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.2,
      metalness: 0.5,
    });

    speakerPositions.forEach((pos, idx) => {
      const spkGroup = new THREE.Group();
      spkGroup.position.set(pos.x, pos.y, pos.z);
      spkGroup.rotation.y = pos.rotY;

      // Stand pillar
      const standPillar = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.25, 12), standMat);
      standPillar.position.y = -0.62;
      spkGroup.add(standPillar);

      const standBase = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.03, 0.35), standMat);
      standBase.position.y = -1.24;
      spkGroup.add(standBase);

      // Speaker cabinet
      const cabinet = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.42, 0.28), speakerCabMat);
      spkGroup.add(cabinet);

      // Yellow Woofer cone (will animate / react to bass hits!)
      const woofer = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.03, 24), yellowConeMat);
      woofer.rotation.x = Math.PI / 2;
      woofer.position.set(0, -0.06, 0.142);
      spkGroup.add(woofer);

      if (idx === 0) this.leftSpeakerWoofer = woofer;
      else this.rightSpeakerWoofer = woofer;

      // Center dust cap
      const dustCap = new THREE.Mesh(new THREE.SphereGeometry(0.03, 16, 16), speakerCabMat);
      dustCap.position.set(0, -0.06, 0.15);
      spkGroup.add(dustCap);

      // Tweeter
      const tweeter = new THREE.Mesh(new THREE.SphereGeometry(0.032, 16, 16), tweeterMat);
      tweeter.position.set(0, 0.11, 0.14);
      spkGroup.add(tweeter);

      // Bass reflex port hole
      const portMat = new THREE.MeshBasicMaterial({ color: 0x050505 });
      const port = new THREE.Mesh(new THREE.CircleGeometry(0.024, 16), portMat);
      port.position.set(0, -0.16, 0.142);
      spkGroup.add(port);

      // Glowing power LED
      const ledMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const led = new THREE.Mesh(new THREE.SphereGeometry(0.005, 8, 8), ledMat);
      led.position.set(0.09, -0.17, 0.142);
      spkGroup.add(led);

      this.group.add(spkGroup);
    });
  }

  private buildMicrophone() {
    this.micGroup.position.set(-0.5, 0.0, -1.0);

    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      metalness: 0.85,
      roughness: 0.2,
    });
    const chromeMat = new THREE.MeshStandardMaterial({
      color: 0xd4d4d8,
      metalness: 0.95,
      roughness: 0.1,
    });

    // Cast iron round base
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.03, 20), metalMat);
    base.position.y = 0.015;
    this.micGroup.add(base);

    // Vertical shaft
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1.1, 10), metalMat);
    shaft.position.y = 0.58;
    this.micGroup.add(shaft);

    // Boom arm joint
    const joint = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 10), chromeMat);
    joint.position.y = 1.13;
    this.micGroup.add(joint);

    // Boom arm angled forward
    const boom = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.65, 8), metalMat);
    boom.rotation.z = -0.4;
    boom.position.set(0.14, 1.25, 0);
    this.micGroup.add(boom);

    // Shockmount ring
    const shockRing = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.006, 8, 20), metalMat);
    shockRing.position.set(0.28, 1.38, 0);
    shockRing.rotation.y = Math.PI / 2;
    this.micGroup.add(shockRing);

    // Studio Large-Diaphragm Condenser Mic
    const micBody = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.12, 16), metalMat);
    micBody.position.set(0.28, 1.38, 0);
    this.micGroup.add(micBody);

    const micGrille = new THREE.Mesh(new THREE.CylinderGeometry(0.023, 0.023, 0.07, 16), chromeMat);
    micGrille.position.set(0.28, 1.46, 0);
    this.micGroup.add(micGrille);

    // Pop Filter
    const popFilterRing = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.005, 8, 24), metalMat);
    popFilterRing.position.set(0.28, 1.46, 0.11);
    this.micGroup.add(popFilterRing);

    const meshScreenMat = new THREE.MeshStandardMaterial({
      color: 0x111111,
      roughness: 0.9,
      transparent: true,
      opacity: 0.75,
    });
    const meshScreen = new THREE.Mesh(new THREE.CircleGeometry(0.063, 24), meshScreenMat);
    meshScreen.position.set(0.28, 1.46, 0.11);
    this.micGroup.add(meshScreen);

    this.group.add(this.micGroup);
  }

  /**
   * Bass woofer cone reaction pulse when kick drum or low notes play
   */
  public pulseWoofers(amount: number = 1.0) {
    if (this.leftSpeakerWoofer && this.rightSpeakerWoofer) {
      this.leftSpeakerWoofer.position.z = 0.142 + 0.012 * amount;
      this.rightSpeakerWoofer.position.z = 0.142 + 0.012 * amount;
    }
  }

  public update(delta: number) {
    // Return speaker cones smoothly to resting position
    if (this.leftSpeakerWoofer && this.leftSpeakerWoofer.position.z > 0.142) {
      this.leftSpeakerWoofer.position.z = THREE.MathUtils.lerp(this.leftSpeakerWoofer.position.z, 0.142, delta * 20);
    }
    if (this.rightSpeakerWoofer && this.rightSpeakerWoofer.position.z > 0.142) {
      this.rightSpeakerWoofer.position.z = THREE.MathUtils.lerp(this.rightSpeakerWoofer.position.z, 0.142, delta * 20);
    }
  }
}
