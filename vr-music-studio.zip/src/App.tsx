/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { VRSettings, AudioSettings } from './types';
import { SoundEngine } from './audio/soundEngine';
import { VRGuitar } from './instruments/vrGuitar';
import { VRDrums } from './instruments/vrDrums';
import { VRControllerStation } from './instruments/vrControllerStation';
import { StudioRoom } from './world/studioRoom';
import { VRStudioUiPanel } from './vr/vrUiPanel';
import { VRManager } from './vr/vrManager';
import {
  Headphones,
  Volume2,
  Radio,
  CheckCircle,
  Disc3,
  Monitor,
  Sparkles,
  Move,
  Eye,
  Music,
  Sliders,
  Play,
} from 'lucide-react';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [xrSupported, setXrSupported] = useState<boolean | null>(null);
  const [isInVR, setIsInVR] = useState(false);
  const [isStudioMode, setIsStudioMode] = useState(false);
  const [activePreset, setActivePreset] = useState<'stage' | 'guitar' | 'drums' | 'controller' | 'mixer'>('stage');
  const [studioNotification, setStudioNotification] = useState<string | null>(null);
  const [sessionError, setSessionError] = useState<string | null>(null);
  const [activeSession, setActiveSession] = useState<XRSession | null>(null);
  const [recorderState, setRecorderState] = useState({ isRecording: false, isPlaying: false, duration: 0, eventCount: 0 });

  const isStudioModeRef = useRef(false);
  useEffect(() => {
    isStudioModeRef.current = isStudioMode;
  }, [isStudioMode]);

  // References to engine instances
  const soundEngineRef = useRef<SoundEngine | null>(null);
  const vrManagerRef = useRef<VRManager | null>(null);
  const guitarRef = useRef<VRGuitar | null>(null);
  const drumsRef = useRef<VRDrums | null>(null);
  const controllerStationRef = useRef<VRControllerStation | null>(null);
  const roomRef = useRef<StudioRoom | null>(null);
  const uiPanelRef = useRef<VRStudioUiPanel | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  // Desktop Navigation Targets
  const targetRigPos = useRef(new THREE.Vector3(0, 0, 0.2));
  const targetRigYaw = useRef(0);
  const targetCameraPitch = useRef(-0.05);
  const currentRigYaw = useRef(0);
  const currentCameraPitch = useRef(-0.05);
  const keysPressed = useRef<{ [k: string]: boolean }>({});

  const isDraggingRef = useRef(false);
  const prevPointerRef = useRef({ x: 0, y: 0 });
  const hasInteractedWithInstrumentRef = useRef(false);

  // Settings
  const vrSettingsRef = useRef<VRSettings>({
    movementMode: 'teleport',
    turnMode: 'snap',
    snapAngle: 45,
    turnSpeed: 1.8,
    leftHanded: false,
  });

  const audioSettingsRef = useRef<AudioSettings>({
    masterVolume: 0.85,
    guitarVolume: 0.9,
    drumVolume: 0.95,
    controllerVolume: 0.9,
  });

  // Check WebXR support gracefully without throwing
  useEffect(() => {
    if ('xr' in navigator && navigator.xr) {
      navigator.xr.isSessionSupported('immersive-vr').then(supported => {
        setXrSupported(supported);
      }).catch(() => {
        setXrSupported(false);
      });
    } else {
      setXrSupported(false);
    }
  }, []);

  // Keyboard navigation & Anti-Back-Navigation Guards
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // Prevent backspace or alt+arrow from navigating browser back
      if (
        (e.key === 'Backspace' && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)) ||
        (e.altKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight'))
      ) {
        e.preventDefault();
      }
      keysPressed.current[e.key.toLowerCase()] = true;
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = false;
    };

    // Reset keys if user alt-tabs or window loses focus (prevents infinite walking back)
    const onBlur = () => {
      keysPressed.current = {};
    };

    // Prevent accidental trackpad/mouse history back swipe
    const handlePopState = () => {
      window.history.pushState(null, '', window.location.href);
    };
    window.history.pushState(null, '', window.location.href);

    // Block auxiliary mouse buttons (e.g. mouse button 3/4 "Back" button)
    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 3 || e.button === 4) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  // Initialize Three.js WebXR Scene
  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Audio Engine
    const soundEngine = new SoundEngine();
    soundEngineRef.current = soundEngine;

    // 2. Three.js Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0c10);

    const camera = new THREE.PerspectiveCamera(
      70,
      window.innerWidth / window.innerHeight,
      0.05,
      50
    );
    camera.position.set(0, 1.65, 0); // Average eye level
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.xr.enabled = true;
    rendererRef.current = renderer;

    containerRef.current.appendChild(renderer.domElement);

    // 3. VR Manager
    const vrManager = new VRManager(renderer, camera, scene, vrSettingsRef.current);
    vrManagerRef.current = vrManager;

    // 4. Studio Room
    const room = new StudioRoom();
    roomRef.current = room;
    scene.add(room.group);

    // 5. Instruments
    const guitar = new VRGuitar(soundEngine);
    guitarRef.current = guitar;
    scene.add(guitar.group);
    scene.add(guitar.standGroup);
    scene.add(guitar.tutorialGroup);

    const drums = new VRDrums(soundEngine);
    drumsRef.current = drums;
    scene.add(drums.group);
    scene.add(drums.stickTableGroup);

    // 6. 16-Pad Performance Controller Station
    const controllerStation = new VRControllerStation(soundEngine);
    controllerStationRef.current = controllerStation;
    scene.add(controllerStation.group);
    soundEngine.setControllerPosition(
      controllerStation.group.position.x,
      0.89,
      controllerStation.group.position.z
    );

    // 7. 3D Studio VR UI Panel
    const uiPanel = new VRStudioUiPanel(
      soundEngine,
      audioSettingsRef.current,
      vrSettingsRef.current,
      (key, value) => {
        if (key === 'movement') {
          vrSettingsRef.current.movementMode = value as any;
        } else if (key === 'turn') {
          vrSettingsRef.current.turnMode = value as any;
        } else if (key === 'handedness') {
          vrSettingsRef.current.leftHanded = Boolean(value);
          guitar.setHandedness(Boolean(value));
        } else if (key === 'recenter') {
          vrManager.recenter();
        }
      }
    );
    uiPanelRef.current = uiPanel;
    scene.add(uiPanel.group);

    // Track recorder state for HUD overlay
    soundEngine.setOnRecorderStateChange(state => {
      setRecorderState({
        isRecording: state.isRecording,
        isPlaying: state.isPlaying,
        duration: state.duration,
        eventCount: state.events.length,
      });
    });

    // Hook Replay visual feedback
    soundEngine.setReplayEventListener(evt => {
      if (evt.type === 'guitar') {
        const strIdx = parseInt(evt.id.replace('string_', ''), 10);
        if (!isNaN(strIdx)) {
          guitar.triggerStringVibration(strIdx, evt.velocity);
        }
      } else if (evt.type === 'drum') {
        drums.triggerZoneVisual(evt.id, evt.velocity);
      } else if (evt.type === 'controller') {
        const padIdx = parseInt(evt.id.replace('pad_', ''), 10);
        if (!isNaN(padIdx)) {
          controllerStation.triggerPad(padIdx, evt.velocity);
        }
      }
      room.pulseWoofers(evt.velocity * 0.6);
    });

    // Handle Window Resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Setup Collision objects for VR Teleportation
    vrManager.floorObjects = [room.floorMesh, room.rugMesh];

    // Frame Clock
    const clock = new THREE.Clock();
    const raycaster = new THREE.Raycaster();

    // WebXR Animation Render Loop
    renderer.setAnimationLoop(() => {
      const delta = Math.min(clock.getDelta(), 0.1);

      // Desktop 3D Mode Navigation & Camera Interpolation
      if (!renderer.xr.isPresenting) {
        if (isStudioModeRef.current) {
          const moveSpeed = 2.4 * delta;
          const forward = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, currentRigYaw.current, 0));
          const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, currentRigYaw.current, 0));

          if (keysPressed.current['w'] || keysPressed.current['arrowup']) {
            targetRigPos.current.addScaledVector(forward, moveSpeed);
          }
          if (keysPressed.current['s'] || keysPressed.current['arrowdown']) {
            targetRigPos.current.addScaledVector(forward, -moveSpeed);
          }
          if (keysPressed.current['a'] || keysPressed.current['arrowleft']) {
            targetRigPos.current.addScaledVector(right, -moveSpeed);
          }
          if (keysPressed.current['d'] || keysPressed.current['arrowright']) {
            targetRigPos.current.addScaledVector(right, moveSpeed);
          }

          // Studio boundary collision
          targetRigPos.current.x = Math.max(-2.6, Math.min(2.6, targetRigPos.current.x));
          targetRigPos.current.z = Math.max(-2.6, Math.min(2.6, targetRigPos.current.z));
        }

        // Smooth camera transitions
        vrManager.userRig.position.lerp(targetRigPos.current, Math.min(1.0, delta * 9));
        currentRigYaw.current += (targetRigYaw.current - currentRigYaw.current) * Math.min(1.0, delta * 12);
        vrManager.userRig.rotation.y = currentRigYaw.current;

        currentCameraPitch.current += (targetCameraPitch.current - currentCameraPitch.current) * Math.min(1.0, delta * 12);
        camera.rotation.x = currentCameraPitch.current;
      }

      // VR Controllers & Tracking Logic
      vrManager.update(
        delta,
        // On Trigger Down
        (ctrlIndex, worldPos, worldRay) => {
          // Check UI Panel Click
          raycaster.ray.copy(worldRay);
          const intersects = raycaster.intersectObject(uiPanel.getMesh());
          if (intersects.length > 0 && intersects[0].uv) {
            const hitBtn = uiPanel.handleRaycast(intersects[0].uv);
            if (hitBtn) {
              uiPanel.clickButton(hitBtn);
            }
          }

          // Check Controller Pad Station Laser Click
          const hitStation = controllerStation.handleRaycast(worldRay);
          if (hitStation) {
            vrManager.triggerHaptic(ctrlIndex, 0.6, 25);
            room.pulseWoofers(0.4);
          }
        },
        // On Grip Down (Pick up guitar or drumsticks)
        (ctrlIndex, worldPos) => {
          // Check Guitar Grab
          if (!guitar.isHeld && guitar.canGrab(worldPos)) {
            guitar.grab(ctrlIndex);
            vrManager.triggerHaptic(ctrlIndex, 0.8, 50);
            return;
          }

          // Check Drumstick Grab
          const candidateStick = drums.canGrabStick(worldPos);
          if (candidateStick) {
            drums.grabStick(candidateStick.id, ctrlIndex);
            vrManager.triggerHaptic(ctrlIndex, 0.7, 40);
            return;
          }
        },
        // On Grip Up (Release guitar or drumsticks)
        (ctrlIndex, worldPos) => {
          // Release Guitar if held by this controller
          if (guitar.isHeld && guitar.holdingControllerIndex === ctrlIndex) {
            guitar.release();
            vrManager.triggerHaptic(ctrlIndex, 0.4, 25);
          }

          // Release Drumstick if held by this controller
          drums.drumSticks.forEach(stick => {
            if (stick.isHeld && stick.holdingControllerIndex === ctrlIndex) {
              drums.releaseStick(stick.id);
              vrManager.triggerHaptic(ctrlIndex, 0.4, 25);
            }
          });
        }
      );

      // A. Update Guitar Position if held in hand
      if (guitar.isHeld && guitar.holdingControllerIndex !== null) {
        const heldCtrl = vrManager.controllers[guitar.holdingControllerIndex];
        guitar.updateHeldPosition(heldCtrl.currPosition, heldCtrl.controller.quaternion);
      }

      // B. Update Drumsticks Position if held in hand
      drums.drumSticks.forEach(stick => {
        if (stick.isHeld && stick.holdingControllerIndex !== null) {
          const heldCtrl = vrManager.controllers[stick.holdingControllerIndex];
          drums.updateHeldStick(stick, heldCtrl.currPosition, heldCtrl.controller.quaternion);
        }
      });

      // C. Update Spatial Audio Listener Position
      const listenerPos = new THREE.Vector3();
      const listenerQuat = new THREE.Quaternion();
      camera.getWorldPosition(listenerPos);
      camera.getWorldQuaternion(listenerQuat);
      soundEngine.updateListener(listenerPos, listenerQuat);

      // D. Strum Guitar with Free Hand or Hand Tracking
      vrManager.controllers.forEach(ctrl => {
        if (guitar.isHeld && ctrl.index === guitar.holdingControllerIndex) return;

        const strumHit = guitar.checkStrum(ctrl.currPosition, delta);
        if (strumHit) {
          soundEngine.playGuitarString(strumHit.stringIndex, strumHit.velocity);
          vrManager.triggerHaptic(ctrl.index, strumHit.velocity, 25);
          room.pulseWoofers(strumHit.velocity * 0.4);
        }
      });

      // E. Check Drum Hits with Drumsticks
      const drumHits = drums.checkHits(delta);
      drumHits.forEach(hit => {
        soundEngine.playDrumHit(hit.hitZone.id, hit.velocity);
        if (hit.stick.holdingControllerIndex !== null) {
          vrManager.triggerHaptic(hit.stick.holdingControllerIndex, hit.velocity, 45);
        }
        room.pulseWoofers(hit.velocity * (hit.hitZone.id === 'kick' ? 1.0 : 0.45));
      });

      // F. Interactive Controller Station Hits (Direct Physical Touch & Drumstick Taps)
      vrManager.controllers.forEach(ctrl => {
        const padHit = controllerStation.checkPhysicalHit(ctrl.currPosition, 0.85);
        if (padHit !== null) {
          vrManager.triggerHaptic(ctrl.index, 0.75, 30);
          room.pulseWoofers(0.5);
        }
      });

      drums.drumSticks.forEach(stick => {
        const stickTip = stick.currTipPos;
        const padHit = controllerStation.checkPhysicalHit(stickTip, stick.isHeld ? 0.9 : 0.6);
        if (padHit !== null) {
          if (stick.isHeld && stick.holdingControllerIndex !== null) {
            vrManager.triggerHaptic(stick.holdingControllerIndex, 0.8, 35);
          }
          room.pulseWoofers(0.6);
        }
      });

      // G. Animate Physics
      guitar.update(delta);
      drums.update(delta);
      controllerStation.update(delta);
      room.update(delta);

      // Render View
      renderer.render(scene, camera);
    });

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.setAnimationLoop(null);
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Enter 3D Desktop / Preview Studio Mode
  const handleEnterStudio3D = () => {
    setSessionError(null);
    if (!soundEngineRef.current) {
      soundEngineRef.current = new SoundEngine();
    }
    soundEngineRef.current.init();
    soundEngineRef.current.resume();
    setIsStudioMode(true);
    setStudioNotification("Entered 3D Studio Mode! Click or drag across instruments to play, WASD to walk, drag to look around.");
    setTimeout(() => setStudioNotification(null), 5000);
  };

  // Enter WebXR Session Gracefully
  const handleEnterVR = async () => {
    setSessionError(null);
    if (!soundEngineRef.current) {
      soundEngineRef.current = new SoundEngine();
    }
    soundEngineRef.current.init();
    soundEngineRef.current.resume();

    // If WebXR is not available in browser, transition directly to 3D studio
    if (!('xr' in navigator) || !navigator.xr) {
      setStudioNotification("WebXR VR is not available in this browser. Welcome to 3D Interactive Studio Mode!");
      setIsStudioMode(true);
      setTimeout(() => setStudioNotification(null), 5000);
      return;
    }

    let isSupported = false;
    try {
      isSupported = await navigator.xr.isSessionSupported('immersive-vr');
    } catch {
      isSupported = false;
    }

    if (!isSupported) {
      // Seamless fallback to 3D Studio Mode without generating uncaught errors
      setStudioNotification("No VR headset detected on this device. Entering 3D Studio Mode with mouse & keyboard controls!");
      setIsStudioMode(true);
      setTimeout(() => setStudioNotification(null), 5000);
      return;
    }

    try {
      const session = await navigator.xr.requestSession('immersive-vr', {
        requiredFeatures: ['local-floor'],
        optionalFeatures: ['hand-tracking'],
      });

      if (rendererRef.current) {
        await rendererRef.current.xr.setSession(session);
        setActiveSession(session);
        setIsInVR(true);
        setIsStudioMode(false);

        session.addEventListener('end', () => {
          setActiveSession(null);
          setIsInVR(false);
          setIsStudioMode(true);
        });
      }
    } catch (err: unknown) {
      // Informative fallback
      const msg = err instanceof Error ? err.message : 'VR session not started';
      console.warn('WebXR session notice:', msg);
      setIsStudioMode(true);
      setStudioNotification("Entering 3D Interactive Studio Mode. You can connect a VR headset anytime!");
      setTimeout(() => setStudioNotification(null), 5000);
    }
  };

  // Exit WebXR Session
  const handleExitVR = async () => {
    if (activeSession) {
      await activeSession.end();
      setActiveSession(null);
      setIsInVR(false);
      setIsStudioMode(true);
    }
  };

  // Camera Presets for 3D Desktop Mode
  const setCameraPreset = (preset: 'stage' | 'guitar' | 'drums' | 'controller' | 'mixer') => {
    setActivePreset(preset);
    if (preset === 'stage') {
      targetRigPos.current.set(0, 0, 0.2); // Positioned comfortably close to the instruments
      targetRigYaw.current = 0;
      targetCameraPitch.current = -0.05;
    } else if (preset === 'guitar') {
      targetRigPos.current.set(-1.05, 0, -0.65);
      targetRigYaw.current = -0.42;
      targetCameraPitch.current = -0.22;
    } else if (preset === 'drums') {
      targetRigPos.current.set(1.3, 0, -0.85);
      targetRigYaw.current = 0.05;
      targetCameraPitch.current = -0.38;
    } else if (preset === 'controller') {
      targetRigPos.current.set(-0.55, 0, -0.38);
      targetRigYaw.current = 0.0;
      targetCameraPitch.current = -0.65;
    } else if (preset === 'mixer') {
      targetRigPos.current.set(0, 0, 0.35);
      targetRigYaw.current = 0.0;
      targetCameraPitch.current = -0.15;
    }
  };

  // Step closer button helper
  const handleStepCloser = () => {
    const forward = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, currentRigYaw.current, 0));
    targetRigPos.current.addScaledVector(forward, 0.4);
    targetRigPos.current.x = Math.max(-2.5, Math.min(2.5, targetRigPos.current.x));
    targetRigPos.current.z = Math.max(-2.5, Math.min(1.2, targetRigPos.current.z));
  };

  // Handle Double Click to Walk to Object
  const handleDoubleClick = (e: React.MouseEvent) => {
    if (isInVR || !cameraRef.current) return;
    const mouse = new THREE.Vector2(
      (e.clientX / window.innerWidth) * 2 - 1,
      -(e.clientY / window.innerHeight) * 2 + 1
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    if (guitarRef.current?.strumHitMesh) {
      const hits = raycaster.intersectObject(guitarRef.current.strumHitMesh);
      if (hits.length > 0) {
        setCameraPreset('guitar');
        return;
      }
    }
    if (drumsRef.current) {
      const hits = raycaster.intersectObjects(drumsRef.current.hitZones.map(z => z.mesh), true);
      if (hits.length > 0) {
        setCameraPreset('drums');
        return;
      }
    }
    if (controllerStationRef.current) {
      const hits = raycaster.intersectObjects(
        [controllerStationRef.current.consoleMesh, ...controllerStationRef.current.pads.map(p => p.mesh)],
        false
      );
      if (hits.length > 0) {
        setCameraPreset('controller');
        return;
      }
    }
    if (roomRef.current?.floorMesh) {
      const hits = raycaster.intersectObject(roomRef.current.floorMesh);
      if (hits.length > 0) {
        targetRigPos.current.set(
          Math.max(-2.2, Math.min(2.2, hits[0].point.x)),
          0,
          Math.max(-2.2, Math.min(1.0, hits[0].point.z))
        );
      }
    }
  };

  // Handle Mouse Wheel Dolly (Zoom In / Step Forward)
  const handleWheel = (e: React.WheelEvent) => {
    if (isInVR) return;
    const forward = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, currentRigYaw.current, 0));
    const step = -Math.sign(e.deltaY) * 0.22;
    targetRigPos.current.addScaledVector(forward, step);
    targetRigPos.current.x = Math.max(-2.5, Math.min(2.5, targetRigPos.current.x));
    targetRigPos.current.z = Math.max(-2.5, Math.min(1.2, targetRigPos.current.z));
  };

  // Handle Pointer / Mouse Interactions in 3D Mode
  const handlePointerDown = (e: React.PointerEvent) => {
    if (isInVR || !cameraRef.current) return;

    if (!soundEngineRef.current) {
      soundEngineRef.current = new SoundEngine();
      soundEngineRef.current.init();
    }
    soundEngineRef.current.resume();

    isDraggingRef.current = true;
    prevPointerRef.current = { x: e.clientX, y: e.clientY };
    hasInteractedWithInstrumentRef.current = false;

    // Raycast check
    const mouse = new THREE.Vector2(
      (e.clientX / window.innerWidth) * 2 - 1,
      -(e.clientY / window.innerHeight) * 2 + 1
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    // 1. Check UI Panel
    if (uiPanelRef.current) {
      const uiIntersects = raycaster.intersectObject(uiPanelRef.current.getMesh());
      if (uiIntersects.length > 0 && uiIntersects[0].uv) {
        const btn = uiPanelRef.current.handleRaycast(uiIntersects[0].uv);
        if (btn) {
          uiPanelRef.current.clickButton(btn);
          hasInteractedWithInstrumentRef.current = true;
          return;
        }
      }
    }

    // 2. Check Guitar Strum
    if (guitarRef.current) {
      const guitarHit = guitarRef.current.handleRaycast(raycaster.ray, 0.85);
      if (guitarHit) {
        if (roomRef.current) roomRef.current.pulseWoofers(0.4);
        hasInteractedWithInstrumentRef.current = true;
        return;
      }
    }

    // 3. Check Drums
    if (drumsRef.current) {
      const drumHit = drumsRef.current.handleRaycast(raycaster.ray, 0.9);
      if (drumHit) {
        if (roomRef.current) {
          roomRef.current.pulseWoofers(drumHit.hitZone.id === 'kick' ? 1.0 : 0.5);
        }
        hasInteractedWithInstrumentRef.current = true;
        return;
      }
    }

    // 4. Check 16-Pad Controller
    if (controllerStationRef.current) {
      const ctrlHit = controllerStationRef.current.handleRaycast(raycaster.ray);
      if (ctrlHit) {
        if (roomRef.current) roomRef.current.pulseWoofers(0.5);
        hasInteractedWithInstrumentRef.current = true;
        return;
      }
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isInVR || !cameraRef.current) return;

    const dx = e.clientX - prevPointerRef.current.x;
    const dy = e.clientY - prevPointerRef.current.y;

    if (isDraggingRef.current) {
      // Check guitar dragging strum
      const mouse = new THREE.Vector2(
        (e.clientX / window.innerWidth) * 2 - 1,
        -(e.clientY / window.innerHeight) * 2 + 1
      );
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, cameraRef.current);

      if (guitarRef.current) {
        const strumVelocity = Math.min(1.0, Math.max(0.4, Math.hypot(dx, dy) * 0.05));
        const guitarHit = guitarRef.current.handleRaycast(raycaster.ray, strumVelocity);
        if (guitarHit) {
          if (roomRef.current) roomRef.current.pulseWoofers(0.35);
          hasInteractedWithInstrumentRef.current = true;
          prevPointerRef.current = { x: e.clientX, y: e.clientY };
          return;
        }
      }

      // If not strumming an instrument, orbit/look around
      if (!hasInteractedWithInstrumentRef.current) {
        targetRigYaw.current -= dx * 0.0035;
        targetCameraPitch.current = Math.max(-1.1, Math.min(1.1, targetCameraPitch.current - dy * 0.0035));
      }
      prevPointerRef.current = { x: e.clientX, y: e.clientY };
    } else {
      // Hover feedback cursor
      if (containerRef.current) {
        const mouse = new THREE.Vector2(
          (e.clientX / window.innerWidth) * 2 - 1,
          -(e.clientY / window.innerHeight) * 2 + 1
        );
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(mouse, cameraRef.current);

        let isOverInteractive = false;
        if (uiPanelRef.current) {
          const hits = raycaster.intersectObject(uiPanelRef.current.getMesh());
          if (hits.length > 0) isOverInteractive = true;
        }
        if (!isOverInteractive && guitarRef.current?.strumHitMesh) {
          const hits = raycaster.intersectObject(guitarRef.current.strumHitMesh);
          if (hits.length > 0) isOverInteractive = true;
        }
        if (!isOverInteractive && drumsRef.current) {
          const hits = raycaster.intersectObjects(drumsRef.current.hitZones.map(z => z.mesh), true);
          if (hits.length > 0) isOverInteractive = true;
        }
        if (!isOverInteractive && controllerStationRef.current) {
          const hits = raycaster.intersectObjects(
            [controllerStationRef.current.consoleMesh, ...controllerStationRef.current.pads.map(p => p.mesh)],
            false
          );
          if (hits.length > 0) isOverInteractive = true;
        }

        containerRef.current.style.cursor = isOverInteractive ? 'pointer' : 'grab';
      }
    }
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
    hasInteractedWithInstrumentRef.current = false;
    if (containerRef.current) {
      containerRef.current.style.cursor = 'grab';
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none text-slate-100">
      {/* 3D WebXR Canvas Container with Pointer Event Listeners */}
      <div
        id="vr-canvas-container"
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onDoubleClick={handleDoubleClick}
        onWheel={handleWheel}
        onContextMenu={(e) => e.preventDefault()}
        className="absolute inset-0 w-full h-full z-0 touch-none cursor-grab active:cursor-grabbing"
      />

      {/* Temporary Toast / Notification */}
      {studioNotification && (
        <div
          id="studio-toast-banner"
          className="absolute top-20 left-1/2 -translate-x-1/2 z-40 px-5 py-2.5 rounded-xl backdrop-blur-md bg-blue-950/90 border border-blue-500/40 shadow-xl text-xs text-blue-100 flex items-center space-x-2 animate-in fade-in slide-in-from-top-4 duration-300 pointer-events-none"
        >
          <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{studioNotification}</span>
        </div>
      )}

      {/* 3D Desktop Studio Mode HUD Overlay (Active when in 3D Mode & not in VR) */}
      {isStudioMode && !isInVR && (
        <div id="desktop-studio-hud" className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-4">
          {/* Top Camera Presets & VR Switch Bar */}
          <div className="flex items-center justify-between w-full max-w-5xl mx-auto pointer-events-auto">
            {/* Quick Perspective Presets */}
            <div className="flex items-center space-x-1 p-1.5 rounded-xl backdrop-blur-md bg-slate-900/85 border border-slate-800 shadow-lg">
              <span className="text-[11px] font-semibold text-slate-400 px-2 uppercase tracking-wider">Perspective:</span>
              <button
                id="preset-stage-btn"
                onClick={() => setCameraPreset('stage')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer flex items-center space-x-1.5 ${
                  activePreset === 'stage' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Stage</span>
              </button>
              <button
                id="preset-guitar-btn"
                onClick={() => setCameraPreset('guitar')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer flex items-center space-x-1.5 ${
                  activePreset === 'guitar' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Music className="w-3.5 h-3.5" />
                <span>Guitar</span>
              </button>
              <button
                id="preset-drums-btn"
                onClick={() => setCameraPreset('drums')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer flex items-center space-x-1.5 ${
                  activePreset === 'drums' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Disc3 className="w-3.5 h-3.5" />
                <span>Drums</span>
              </button>
              <button
                id="preset-controller-btn"
                onClick={() => setCameraPreset('controller')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer flex items-center space-x-1.5 ${
                  activePreset === 'controller' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>16-Pad Synth</span>
              </button>
              <button
                id="preset-mixer-btn"
                onClick={() => setCameraPreset('mixer')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer flex items-center space-x-1.5 ${
                  activePreset === 'mixer' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Mixer</span>
              </button>
              <div className="w-px h-4 bg-slate-700 mx-1" />
              <button
                id="step-closer-btn"
                onClick={handleStepCloser}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-blue-300 hover:text-white bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/30 transition-all cursor-pointer flex items-center space-x-1 shadow-sm"
                title="Step forward closer to instruments (or scroll mouse wheel up)"
              >
                <Move className="w-3 h-3" />
                <span>Step Closer</span>
              </button>
            </div>

            {/* Right Side Mode Status & VR Switch */}
            <div className="flex items-center space-x-2">
              {recorderState.isRecording && (
                <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-red-950/80 border border-red-500/50 text-red-300 text-xs animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  <span className="font-semibold">REC ({Math.floor(recorderState.duration)}s)</span>
                </div>
              )}
              {recorderState.isPlaying && (
                <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs">
                  <Play className="w-3 h-3 text-emerald-400 fill-current" />
                  <span className="font-semibold">Replay Active</span>
                </div>
              )}

              <button
                id="switch-vr-headset-btn"
                onClick={handleEnterVR}
                className="px-3.5 py-1.5 rounded-lg backdrop-blur-md bg-blue-600/90 hover:bg-blue-500 text-white text-xs font-semibold border border-blue-400/40 shadow-lg cursor-pointer flex items-center space-x-2 transition-colors"
                title="Launch in VR Headset"
              >
                <Radio className="w-3.5 h-3.5" />
                <span>Launch VR</span>
              </button>

              <button
                id="exit-studio-mode-btn"
                onClick={() => setIsStudioMode(false)}
                className="px-3 py-1.5 rounded-lg backdrop-blur-md bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-medium border border-slate-700/60 shadow-lg cursor-pointer transition-colors"
              >
                Menu
              </button>
            </div>
          </div>

          {/* Bottom Desktop Controls Helper Strip */}
          <div className="flex items-center justify-between w-full max-w-4xl mx-auto pointer-events-auto">
            <div className="flex items-center space-x-4 px-4 py-2 rounded-xl backdrop-blur-md bg-slate-900/80 border border-slate-800 text-xs text-slate-300 shadow-lg">
              <div className="flex items-center space-x-1.5 text-blue-400">
                <Move className="w-3.5 h-3.5" />
                <span className="text-white font-medium">Click / Drag:</span>
                <span className="text-slate-300">Strum guitar, strike drums, tap pads</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="flex items-center space-x-1.5">
                <span className="font-semibold text-slate-200">WASD:</span>
                <span>Move</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="flex items-center space-x-1.5">
                <span className="font-semibold text-slate-200">Scroll / Dbl-Click:</span>
                <span>Zoom & Step close</span>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs text-slate-400 px-3 py-2 rounded-xl backdrop-blur-md bg-slate-900/70 border border-slate-800">
              <Volume2 className="w-3.5 h-3.5 text-blue-400" />
              <span>Spatial Stage Audio Active</span>
            </div>
          </div>
        </div>
      )}

      {/* VR Launcher Overlay (visible when not in an active WebXR session and not in 3D studio mode) */}
      {!isInVR && !isStudioMode && (
        <div id="vr-launcher-overlay" className="absolute inset-0 z-20 flex flex-col items-center justify-between p-6 pointer-events-none bg-radial from-transparent via-slate-950/70 to-slate-950/95">
          {/* Top Brand & Status */}
          <header className="flex items-center justify-between w-full max-w-4xl px-4 py-3 rounded-xl backdrop-blur-md bg-slate-900/80 border border-slate-800 pointer-events-auto">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <Disc3 className="w-6 h-6 animate-spin" style={{ animationDuration: '6s' }} />
              </div>
              <div>
                <h1 className="text-lg font-semibold tracking-wide text-white">VR Music Studio</h1>
                <p className="text-xs text-slate-400">Immersive VR & 3D Spatial Acoustic Stage</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${xrSupported ? 'bg-emerald-400 opacity-75' : 'bg-blue-400 opacity-75'}`}></span>
                <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${xrSupported ? 'bg-emerald-500' : 'bg-blue-500'}`}></span>
              </span>
              <span className="text-xs font-medium text-slate-300">
                {xrSupported === null ? 'Checking WebXR...' : xrSupported ? 'VR Headset Detected' : '3D Studio Mode Ready'}
              </span>
            </div>
          </header>

          {/* Center Entry Card */}
          <div className="flex flex-col items-center max-w-md w-full p-8 rounded-2xl backdrop-blur-xl bg-slate-900/90 border border-slate-700/60 shadow-2xl pointer-events-auto text-center my-auto">
            <div className="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 mb-5">
              <Headphones className="w-12 h-12" />
            </div>

            <h2 className="text-2xl font-bold text-white mb-2">Step into the Studio</h2>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              Experience the 3D acoustic room with interactive acoustic guitar, full drum kit, 16-pad performance controller station, and live performance recording.
            </p>

            {/* Primary Action Buttons */}
            <div className="w-full space-y-3">
              <button
                id="enter-studio-3d-btn"
                onClick={handleEnterStudio3D}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-base tracking-wide transition-all duration-200 shadow-lg flex items-center justify-center space-x-3 bg-blue-600 hover:bg-blue-500 active:scale-98 text-white cursor-pointer hover:shadow-blue-500/25"
              >
                <Monitor className="w-5 h-5" />
                <span>Enter 3D Studio Mode</span>
              </button>

              <button
                id="enter-vr-btn"
                onClick={handleEnterVR}
                className="w-full py-3 px-6 rounded-xl font-semibold text-sm tracking-wide transition-all duration-200 shadow-md flex items-center justify-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 cursor-pointer"
              >
                <Radio className="w-4 h-4 text-blue-400" />
                <span>Launch in VR Headset (WebXR)</span>
              </button>
            </div>

            {sessionError && (
              <div className="mt-4 p-3 rounded-lg bg-amber-900/40 border border-amber-700/50 text-xs text-amber-200 text-left w-full">
                <strong>Notice:</strong> {sessionError}
                <div className="mt-1 text-[11px] text-slate-400">
                  You can use 3D Studio Mode with your mouse and keyboard, or open in a WebXR-compatible VR browser.
                </div>
              </div>
            )}

            {/* Quick Interaction Overview */}
            <div className="grid grid-cols-2 gap-3 mt-6 pt-6 border-t border-slate-800 text-left w-full">
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                <span className="text-xs text-slate-300">Strum 6 individual strings</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                <span className="text-xs text-slate-300">Physical drum kit & cymbals</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                <span className="text-xs text-slate-300">16-pad beat & synth station</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                <span className="text-xs text-slate-300">VR 6DOF + Mouse controls</span>
              </div>
            </div>
          </div>

          {/* Bottom Audio Tip */}
          <footer className="flex items-center justify-center space-x-2 text-xs text-slate-400 px-4 py-2 rounded-full backdrop-blur-md bg-slate-900/60 border border-slate-800/80">
            <Volume2 className="w-4 h-4 text-blue-400" />
            <span>Low-latency HRTF spatial audio active. Headphones recommended for best acoustic resonance.</span>
          </footer>
        </div>
      )}

      {/* Active VR Indicator (only shows when WebXR session is active) */}
      {isInVR && (
        <div className="absolute top-4 right-4 z-30 pointer-events-auto">
          <button
            id="exit-vr-btn"
            onClick={handleExitVR}
            className="px-4 py-2 rounded-lg bg-red-600/80 hover:bg-red-500 text-white text-xs font-semibold backdrop-blur-sm border border-red-400/40 cursor-pointer shadow-lg"
          >
            Exit VR Session
          </button>
        </div>
      )}
    </div>
  );
}
