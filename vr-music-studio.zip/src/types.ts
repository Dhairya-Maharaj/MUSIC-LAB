export type InstrumentType = 'guitar' | 'drum' | 'controller';

export interface PerformanceEvent {
  time: number; // milliseconds from record start
  type: InstrumentType;
  id: string; // e.g. 'guitar_string_0' to '5', 'kick', 'snare', 'pad_0', etc.
  noteName?: string;
  velocity: number;
}

export interface RecorderState {
  isRecording: boolean;
  isPlaying: boolean;
  startTime: number;
  duration: number;
  events: PerformanceEvent[];
  playbackProgress: number; // 0 to 1
}

export interface AudioSettings {
  masterVolume: number; // 0 to 1
  guitarVolume: number; // 0 to 1
  drumVolume: number;   // 0 to 1
  controllerVolume: number; // 0 to 1
}

export interface VRSettings {
  movementMode: 'teleport' | 'smooth';
  turnMode: 'snap' | 'smooth';
  snapAngle: number; // e.g. 45 degrees
  turnSpeed: number;
  leftHanded: boolean;
  showControllerHud?: boolean;
}

export interface ControllerPadConfig {
  id: number;
  name: string;
  category: 'chord' | 'bass' | 'beat' | 'fx';
  color: number; // Hex color for pad LED
  label: string;
}

export interface GuitarStringConfig {
  index: number;
  name: string;
  note: string;
  frequency: number;
  thickness: number;
  color: string;
}

export interface DrumPartConfig {
  id: string;
  name: string;
  pitch: number;
  type: 'kick' | 'snare' | 'hihat_closed' | 'hihat_open' | 'crash' | 'ride' | 'tom_high' | 'tom_mid' | 'tom_floor';
}
